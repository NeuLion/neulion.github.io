//
//  NLCategory.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSModel.h"

@interface NLSCategory : NLSModel

/** The ID of the category */
@property (nonatomic, copy) NSString * categoryId;

/** The SEO name that would exist in the URL when calling the Category API. */
@property (nonatomic, copy) NSString * seoName;

/** The name of the category. */
@property (nonatomic, copy) NSString * name;

/** The description of the category */
@property (nonatomic, copy) NSString * categoryDescription;

/** 
 * The release date of the category 
 * @note Example: 2013-04-10T00:00:00.000
 */
@property (nonatomic, copy) NSString * releaseDate;

@property (nonatomic, strong) NSArray * subCategories;

@property (nonatomic, strong) NSArray * programs;

@end
