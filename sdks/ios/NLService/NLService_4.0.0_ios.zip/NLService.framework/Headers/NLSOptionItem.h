//
//  NLSOptionItem.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-10.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//
#import "NLSModel.h"

@interface NLSOptionItem : NLSModel

@property (nonatomic, copy) NSString * label;
@property (nonatomic, copy) NSString * value;

@end
