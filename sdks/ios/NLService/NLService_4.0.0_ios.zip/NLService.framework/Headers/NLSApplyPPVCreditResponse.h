//
//  NLSApplyPPVCreditResponse.h
//  NeuLionService
//
//  Created by Chengming on 16/10/12.
//  Copyright © 2016年 NeuLion, Inc. All rights reserved.
//

#import <NLService/NLService.h>

@interface NLSApplyPPVCreditResponse : NLSResponse

@property (copy, nullable, nonatomic) NSString     *code;

- (BOOL)isSubscribedSuccess;

@end
