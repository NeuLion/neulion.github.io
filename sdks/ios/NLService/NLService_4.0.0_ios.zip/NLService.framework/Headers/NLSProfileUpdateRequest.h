//
//  NLProfileUpdateRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSProfileUpdateRequest : NLSRequest

@property (copy, nullable, nonatomic) NSString *email;
@property (copy, nullable, nonatomic) NSString *firstname;
@property (copy, nullable, nonatomic) NSString *lastname;
@property (copy, nullable, nonatomic) NSString *locale;
@property (copy, nullable, nonatomic) NSString *password;
@property (copy, nullable, nonatomic) NSString *address1;
@property (copy, nullable, nonatomic) NSString *address2;
@property (copy, nullable, nonatomic) NSString *city;
@property (copy, nullable, nonatomic) NSString *state;
@property (copy, nullable, nonatomic) NSString *zip;
@property (copy, nullable, nonatomic) NSString *country;
@property (copy, nullable, nonatomic) NSString *optinnews;
@property (copy, nullable, nonatomic) NSString *optininfo;

@end
NS_ASSUME_NONNULL_END