//
//  NLSPayPerViewOrder.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-16.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"
@class NLSPrice;

@interface NLSPayPerViewOrder : NLSModel

@property (nonatomic, copy) NSString * purchaseDate;
@property (nonatomic, copy) NSString * payPerViewdescription;
@property (nonatomic, copy) NLSPrice * price;
@property (nonatomic, copy) NSString * type;
@property (nonatomic, copy) NSString * sku;
@property (nonatomic, copy) NSString * contentId;
@property (nonatomic, copy) NSString * isActive;

@end
