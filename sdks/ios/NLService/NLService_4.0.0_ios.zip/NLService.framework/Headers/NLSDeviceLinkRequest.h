//
//  NLDeviceLinkRequest.h
//  NeulionService
//
//  Copyright (c) 2014 Neulion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"

NS_ASSUME_NONNULL_BEGIN
typedef enum _NLServiceDeviceType{
    NLServiceDeviceTypePC = 0,
	NLServiceDeviceTypeAdobeAir = 5,
    NLServiceDeviceTypeiPadMobileDevice = 6,
	NLServiceDeviceTypeiPhoneMobileDevice = 7,
    NLServiceDeviceTypeAndroidMobileDevice = 8,
	NLServiceDeviceTypeBlackBerryMobileDevice = 9,
    NLServiceDeviceTypeNokiaMobileDevice = 10,
	NLServiceDeviceTypeWindowsMobileDevice = 11,
    NLServiceDeviceTypeWindowsApp = 12,
	NLServiceDeviceTypeAndroidTabletMobileDevice = 13,
    NLServiceDeviceTypeBoxeeSTB = 129,
	NLServiceDeviceTypeSonyBraviaSmartTV = 130,
    NLServiceDeviceTypePlayStationGameConsole = 131,
	NLServiceDeviceTypeRokuSTB = 132,
    NLServiceDeviceTypeSamsungSmartTV = 133,
	NLServiceDeviceTypeLGSmartTV = 134,
    NLServiceDeviceTypeVizioSmartTV = 135,
	NLServiceDeviceTypePanasonicSmartTV = 136,
    NLServiceDeviceTypeXboxGameConsole = 137,
    NLServiceDeviceTypeGoogleTVSTB = 138,
    NLServiceDeviceTypeAppleTVSTB = 139,
    NLServiceDeviceTypePSVitaSmartTV = 140
} NLServiceDeviceType;

@interface NLSDeviceLinkRequest : NLSRequest

@property (copy, nonatomic) NSString     *username;
@property (copy, nonatomic) NSString     *password;
@property (copy, nullable, nonatomic) NSString     *deviceid;
@property (copy, nullable, nonatomic) NSString     *devicetype;
@property (copy, nullable, nonatomic) NSString     *devicename;

-(instancetype)initWithUsername:(NSString *)username andPassword:(NSString *)password;

@end
NS_ASSUME_NONNULL_END