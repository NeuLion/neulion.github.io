//
//  NLGameDate.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSModel.h"

@interface NLSGameDate : NLSModel

@property (nonatomic, copy) NSString * date;
@property (nonatomic, assign) NSUInteger count;

@end
