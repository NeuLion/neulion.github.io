//
//  NLSPUserRecord.h
//  NeuLionService
//
//  Created by Chengming on 16/2/24.
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"

@interface NLSPUserRecord : NLSModel

@property (nonatomic, copy) NSString * recordId;
@property (nonatomic, copy) NSString * lastUpdated;
@property (nonatomic, copy) NSString * type;
@property (nonatomic, copy) NSString * position;

@end
