//
//  NLSEPGItem.h
//  NeuLionService
//
//  Created by NeuLion Developer on 15-2-26.
//  Copyright (c) 2015 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"

@interface NLSEPGItem : NLSModel

@property (nonatomic, copy) NSString * channelId;
@property (nonatomic, copy) NSString * seoName;
@property (nonatomic, strong) NSMutableArray * items;

@end
