//
//  NLSubscriptionsResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN
@class NLSSubscription;

@interface NLSSubscriptionsResponse : NLSResponse

@property (nullable, nonatomic, copy) NSString * code;
@property (nullable, nonatomic, strong) NLSSubscription * subscriptions;

@end
NS_ASSUME_NONNULL_END