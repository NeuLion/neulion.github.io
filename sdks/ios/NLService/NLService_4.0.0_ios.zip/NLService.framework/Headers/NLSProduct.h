//
//  NLSProduct.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSModel.h"

@interface NLSProduct : NLSModel

/**
 *  Usually named by the client or product name.
 */
@property (copy, nonatomic) NSString *productType;

/**
 *  The value may be used for In-App Purchase for mobile apps.
 */
@property (copy, nonatomic) NSString *sku;

/**
 *  The ID of the product.
 */
@property (copy, nonatomic) NSString *productId;

/**
 *  The name of the product.
 */
@property (copy, nonatomic) NSString *name;

/**
 *  The description of the product.
 */
@property (copy, nonatomic) NSString *productDescription;

/**
 *  The price of the product. Float number format, e.g. "59.99".
 */
@property (copy, nonatomic) NSString *price;

/**
 *  The currency symbol according to the users’ area, e.g. "USD$".
 */
@property (copy, nonatomic) NSString *currency;
@end
