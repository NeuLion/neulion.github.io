//
//  NLSProgramsResponse.h
//  NeuLionService
//
//  Created by Chengming on 16/2/1.
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import <NLService/NLService.h>
NS_ASSUME_NONNULL_BEGIN

@interface NLSProgramsResponse : NLSResponse

@property (nullable, nonatomic, strong) NSArray * programs;

@end
NS_ASSUME_NONNULL_END