//
//  NLSParsableDataModelProtocol.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>

@protocol NLSParsableDataModelProtocol <NSObject>

@required
+ (NSString *)parseRootPath;
+ (NSDictionary *)propertyMapping;
+ (NSDictionary *)relationshipMapping;
@optional
- (void)parseData;

@end
