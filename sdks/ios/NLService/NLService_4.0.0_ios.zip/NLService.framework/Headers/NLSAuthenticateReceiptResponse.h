//
//  NLSAuthenticateReceiptResponse.h
//  NeuLionService
//
//  Created by Chengming on 16/7/14.
//  Copyright © 2016年 NeuLion, Inc. All rights reserved.
//

#import "NLSResponse.h"

NS_ASSUME_NONNULL_BEGIN
@class NLSAuthenticationInfo;

@interface NLSAuthenticateReceiptResponse : NLSResponse

@property (copy, nullable, nonatomic) NSString     *code;
@property (nullable, nonatomic, strong) NLSAuthenticationInfo * data;

@end
NS_ASSUME_NONNULL_END