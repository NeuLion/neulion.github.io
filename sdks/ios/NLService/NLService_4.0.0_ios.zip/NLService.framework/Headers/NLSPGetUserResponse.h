//
//  NLSPGetUserResponse.h
//  NeuLionService
//
//  Created by Chengming on 16/2/24.
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import "NLSPersonalizeResponse.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSPGetUserResponse : NLSPersonalizeResponse

@property (nullable, nonatomic, copy) NSString * userId;
@property (nullable, nonatomic, copy) NSString * name;
@property (nullable, nonatomic, copy) NSString * age;
@property (nullable, nonatomic, copy) NSString * job;

@end
NS_ASSUME_NONNULL_END