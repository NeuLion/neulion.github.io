//
//  NLRegistrationFormResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN
@class NLSDateOfBirth;
@class NLSOptionItem;

@interface NLSRegistrationFormResponse : NLSResponse

@property (copy, nullable, nonatomic)     NSArray     *referSources;
@property (copy, nullable, nonatomic)     NSArray     *locales;
@property (strong, nullable, nonatomic)   NLSDateOfBirth * dob;
@property (copy, nullable, nonatomic)     NSString    *minAge;
@property (copy, nullable, nonatomic)     NSString    *maxYear;
@property (copy, nullable, nonatomic)     NSString    *minYear;
@property (copy, nullable, nonatomic)     NSArray     *attributes;

@end
NS_ASSUME_NONNULL_END