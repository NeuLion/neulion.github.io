//
//  NLSProgramsRequest.h
//  NeuLionService
//
//  Created by Chengming on 16/2/1.
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import <NLService/NLService.h>
NS_ASSUME_NONNULL_BEGIN
@interface NLSProgramsRequest : NLSRequest

@property (nullable, nonatomic, copy) NSString * ids;

- (instancetype)initWithProgramIdArray:(NSArray *)programIdArray;

@end
NS_ASSUME_NONNULL_END