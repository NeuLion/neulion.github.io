//
//  NLCategoryProgramsByIdResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
#import "NLSPaging.h"
NS_ASSUME_NONNULL_BEGIN

@interface NLSCategoryProgramsResponse : NLSResponse

/** 
 * Contains the paging information for programs (if any), all sub-element values are integers
 * @see NLSPaging for more information
 */
@property (nullable, nonatomic, strong) NLSPaging * paging;

/** Category ID */
@property (nullable, nonatomic, copy) NSString * categoryId;

/** Category SEO name */
@property (nullable, nonatomic, copy) NSString * seoName;

/** Category name */
@property (nullable, nonatomic, copy) NSString * name;

/** Category description */
@property (nullable, nonatomic, copy) NSString * categoryDescription;

/** Category release date */
@property (nullable, nonatomic, copy) NSString * releaseDate;

/**
 * Sub-categories in category if any.  Child <category> elements have same elements as above.
 * @see NLSCategory for more information
 */
@property (nullable, nonatomic, strong) NSArray * subCategories;

/**
 * Programs in category if any.  Please check the Program data type definition section for details.
 * @see NLSProgram for more information
 */
@property (nullable, nonatomic, strong) NSArray * programs;


@property (nullable, nonatomic, strong) NSArray * programGroups;


@property (nullable, nonatomic, strong) NSString * style;

@end
NS_ASSUME_NONNULL_END