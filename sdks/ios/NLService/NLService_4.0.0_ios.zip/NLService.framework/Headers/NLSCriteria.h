//
//  NLSCriteria.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-11.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"

@interface NLSCriteria : NLSModel

@property (nonatomic, copy) NSString * type;
@property (nonatomic, copy) NSString * parameter;
@property (nonatomic, copy) NSString * releaseDays;
@property (nonatomic, copy) NSString * minDate;
@property (nonatomic, copy) NSString * maxDate;
@property (nonatomic, copy) NSString * filterQuery;
@property (nonatomic, copy) NSString * sort;

@end
