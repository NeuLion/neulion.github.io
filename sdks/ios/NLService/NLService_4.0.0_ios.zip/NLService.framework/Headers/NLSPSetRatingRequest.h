//
//  NLSPSetRatingRequest.h
//  NeuLionService
//
//  Created by Chengming on 16/2/24.
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import "NLSPersonalizeRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSPSetRatingRequest : NLSPersonalizeRequest

@property (nullable, nonatomic, copy) NSString * contentId;
//value (1~5)
@property (nullable, nonatomic, copy) NSString * rating;
@property (nullable, nonatomic, copy) NSString * type;

@end
NS_ASSUME_NONNULL_END