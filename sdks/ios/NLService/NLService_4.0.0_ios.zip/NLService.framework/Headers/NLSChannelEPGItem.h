//
//  NLSChannelEPGItem.h
//  NeuLionService
//
//  Created by NeuLion Developer on 15-2-26.
//  Copyright (c) 2015 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"

@interface NLSChannelEPGItem : NLSModel

@property (nonatomic, copy) NSString * startTimeLocalTimeZone;
@property (nonatomic, copy) NSString * startTimeUTC;
@property (nonatomic, copy) NSString * duration;
@property (nonatomic, copy) NSString * programTitle;
@property (nonatomic, copy) NSString * programDescription;
@property (nonatomic, copy) NSString * tag;
@property (nonatomic, copy) NSString * programId;

@end
