//
//  NLServiceRequest.h
//  NeulionService
//
//  Copyright (c) 2014 Neulion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSObject.h"
NS_ASSUME_NONNULL_BEGIN

@class NLSResponse;

typedef void (^NLServiceCompletionBlock)(NLSResponse * response);


@protocol NLServiceRequestProtocol <NSObject>

@required
/**
 *  The relative path of the API request that would be used to form complete URL. All subclass of the NLSRequest should override the method and return the relative path of the corresponding API according to the API document.
 *
 *  @return The relative path of the API request.
 */
- (nullable NSString *)apiPath;

/**
 *  The HTTP Method (GET, POST) used for the request. This method returns "POST" by default. If the API uses GET method, the API's request subclass should override the method and return "GET", case sensitive.
 *
 *  @return "POST" or "GET" string.
 */
- (nullable NSString *)httpMethod;

/**
 *  Request via https or http. The method returns NO by default. If the API's request subclass needs to use the https, it should override the method and return YES.
 *
 *  @return YES, if the API needs to use https.
 */
- (BOOL)useHTTPS;

@optional
/**
 *  The response class corresonding to the current request class. The method establishes relationship between response class with the request class.
 *
 *  @return The response class.
 */
- (nullable Class)responseClass;

/**
 *  The alias of the parameter in the request named "id". Since "id" is the keyword in Objective-C language, this method points out which property of the request class is used as the alias of the "id" paramter.
 *
 *  @return The name of the proeprty of the request class, which acts as the alias of the "id" parameter in the request.
 */
- (nullable NSString *)idPropertyAlias;


- (nullable NSString *)specifiedServerUrl;


- (BOOL)encodeParams;

- (nullable NSString *)feedFormat;

- (nullable NSDictionary *)propertyAliasDictionary;

- (BOOL)manualParsingData;

@end


@interface NLSRequest : NLSObject<NLServiceRequestProtocol>

@property (nonatomic, copy, nullable) NLServiceCompletionBlock serviceCompletionBlock;
@property (nonatomic, strong,nullable) id userInfo;

-(nullable NSMutableDictionary *)apiParams;
-(nullable NSMutableDictionary *)apiHeaders;
-(nullable NSString *)queryString;
-(nullable NSArray *)allPropertyNames;
@end
NS_ASSUME_NONNULL_END
