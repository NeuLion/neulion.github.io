//
//  NLSPersonalizeResponse.h
//  NeuLionService
//
//  Created by Chengming on 16/2/24.
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSPersonalizeResponse : NLSResponse

@property (nullable, nonatomic, copy) NSString * code;

@end

extern NSString * const  NLSPersonalizeNeedRefreshAccessTokenNotification;
NS_ASSUME_NONNULL_END