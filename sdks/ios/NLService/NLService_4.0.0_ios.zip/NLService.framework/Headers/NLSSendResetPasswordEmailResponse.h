//
//  NLResetPasswordEmailResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSSendResetPasswordEmailResponse : NLSResponse

@property (copy, nullable, nonatomic) NSString     *code;

@end
NS_ASSUME_NONNULL_END