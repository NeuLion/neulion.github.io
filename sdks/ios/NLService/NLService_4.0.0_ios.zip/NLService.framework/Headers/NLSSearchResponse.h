//
//  NLSearchResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN

@class NLSPaging;
@class NLSCriteria;

@interface NLSSearchResponse : NLSResponse

@property (nullable, nonatomic, strong) NLSPaging * paging;
@property (nullable, nonatomic, strong) NSArray * programs;
@property (nullable, nonatomic, strong) NLSCriteria * criteria;

@end
NS_ASSUME_NONNULL_END