//
//  NLTeam.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSModel.h"

@interface NLSTeam : NLSModel

/** The team identifier */
@property (nonatomic, copy) NSString * teamId;

/** Usually the abbreviation of the team name and used as a part of the logo image file name. */
@property (nonatomic, copy) NSString * code;

/** The name of the team. */
@property (nonatomic, copy) NSString * name;

/** The host city of the team.  */
@property (nonatomic, copy) NSString * city;

/** The score of the team in the games result. */
@property (nonatomic, copy) NSString * score;

@end
