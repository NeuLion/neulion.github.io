//
//  NLSPersonalizeRequest.h
//  NeuLionService
//
//  Created by Chengming on 16/2/24.
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSPersonalizeRequest : NLSRequest

@property (nullable, nonatomic, copy) NSString * uid;
@property (nullable, nonatomic, copy) NSString * token;

@end
NS_ASSUME_NONNULL_END