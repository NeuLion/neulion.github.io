//
//  NLSEPGResponse.h
//  NeuLionService
//
//  Created by NeuLion Developer on 15-2-26.
//  Copyright (c) 2015 NeuLion, Inc. All rights reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN

@interface NLSEPGResponse : NLSResponse
@property (nullable, nonatomic, strong) NSArray * EPGItems;
@end
NS_ASSUME_NONNULL_END