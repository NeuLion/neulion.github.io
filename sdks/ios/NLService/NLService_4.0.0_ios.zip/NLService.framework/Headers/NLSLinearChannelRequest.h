//
//  NLLinearChannelRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSLinearChannelRequest : NLSRequest{
    NSString *_seoName;
}
@property (nullable, nonatomic, copy) NSString * channelId;
@property (nullable, nonatomic, copy) NSString * extid;

- (instancetype)initWithLinearChannelId:(NSString *)linearChannelId;
- (instancetype)initWithExtId:(NSString *)extId;
- (instancetype)initWithSeoName:(NSString *)seoName;
@end
NS_ASSUME_NONNULL_END