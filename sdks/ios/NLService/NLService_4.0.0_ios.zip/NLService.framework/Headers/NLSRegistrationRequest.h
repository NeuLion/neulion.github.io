//
//  NLRegistrationRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN

@interface NLSRegistrationRequest : NLSRequest

@property (copy, nonatomic) NSString *username;
@property (copy, nonatomic) NSString *email;
@property (copy, nullable, nonatomic) NSString *password;
@property (copy, nullable, nonatomic) NSString *firstname;
@property (copy, nullable, nonatomic) NSString *lastname;
@property (copy, nullable, nonatomic) NSString *locale;
@property (copy, nullable, nonatomic) NSString *dobyear;
@property (copy, nullable, nonatomic) NSString *dobmonth;
@property (copy, nullable, nonatomic) NSString *dobdate;
@property (copy, nullable, nonatomic) NSString *referrer;
@property (copy, nullable, nonatomic) NSString *billing_address1;
@property (copy, nullable, nonatomic) NSString *billing_address2;
@property (copy, nullable, nonatomic) NSString *billing_city;
@property (copy, nullable, nonatomic) NSString *billing_state;
@property (copy, nullable, nonatomic) NSString *billing_zip;
@property (copy, nullable, nonatomic) NSString *billing_country;
@property (copy, nullable, nonatomic) NSString *contact_address1;
@property (copy, nullable, nonatomic) NSString *contact_address2;
@property (copy, nullable, nonatomic) NSString *contact_city;
@property (copy, nullable, nonatomic) NSString *contact_state;
@property (copy, nullable, nonatomic) NSString *contact_zip;
@property (copy, nullable, nonatomic) NSString *contact_country;
@property (copy, nullable, nonatomic) NSString *phone;
@property (copy, nullable, nonatomic) NSString *cardnumber;
@property (copy, nullable, nonatomic) NSString *cardexpmonth;
@property (copy, nullable, nonatomic) NSString *cardexpyear;
@property (copy, nullable, nonatomic) NSString *cardholder;
@property (copy, nullable, nonatomic) NSString *cardtype;
@property (copy, nullable, nonatomic) NSString *cardsc;
@property (copy, nullable, nonatomic) NSString *optinnews;
@property (copy, nullable, nonatomic) NSString *optininfo;

-(instancetype)initWithUsername:(NSString *)username andPassword:(NSString *)password;

@end
NS_ASSUME_NONNULL_END