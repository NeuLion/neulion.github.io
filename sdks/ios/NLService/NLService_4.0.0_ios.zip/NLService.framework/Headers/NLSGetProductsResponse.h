//
//  NLGetProductsResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN
@class NLSProduct;

@interface NLSGetProductsResponse : NLSResponse

@property (nullable, nonatomic, strong) NSArray * products;

@end
NS_ASSUME_NONNULL_END