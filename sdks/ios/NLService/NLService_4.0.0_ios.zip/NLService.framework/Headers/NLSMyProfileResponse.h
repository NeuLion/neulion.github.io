//
//  NLMyProfileResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN
@class NLSResult;
@class NLSProfile;

@interface NLSMyProfileResponse : NLSResponse

@property (nullable, nonatomic, strong) NSString         * code;
@property (nullable, nonatomic, strong) NLSProfile       * profile;


@end
NS_ASSUME_NONNULL_END