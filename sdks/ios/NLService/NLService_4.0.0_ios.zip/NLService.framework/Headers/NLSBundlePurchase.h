//
//  NLBundlePurchase.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSModel.h"
#import "NLSPrice.h"

@interface NLSBundlePurchase : NLSModel

/** The purchase type string */
@property (nonatomic, copy) NSString * type;

/** The SKU of the purchasing item */
@property (nonatomic, copy) NSString * sku;

/** The bundle identifier of the purchasing item  */
@property (nonatomic, copy) NSString * bundleId;

/** The name of the purchasing item  */
@property (nonatomic, copy) NSString * name;

/** The description of the purchasing item  */
@property (nonatomic, copy) NSString * desc;

/**
 *  The price information of the product
 * @see NLSPrice for more information.
 */
@property (nonatomic, strong) NLSPrice * price;

/**
 *  The price information of the product
 * @see NLSPrice for more information.
 */
@property (nonatomic, strong) NLSPrice * discount;

@end
