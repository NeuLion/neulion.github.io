//
//  NLSGameTwitterAccounts.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-9.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//


#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSGameTwitterAccountsRequest : NLSRequest

@property (nonatomic, copy) NSString *gameId;

- (instancetype)initWithGameId:(NSString *)gameId;

@end
NS_ASSUME_NONNULL_END