//
//  NLSearchRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSSearchRequest : NLSRequest{
    BOOL _isServiceSearch;
}

@property (nullable, nonatomic, copy) NSString * type;
@property (nullable, nonatomic, copy) NSString * fq;
@property (nullable, nonatomic, copy) NSString * cid;
@property (nullable, nonatomic, copy) NSString * sid;
@property (nullable, nonatomic, copy) NSString * lid;
@property (nullable, nonatomic, copy) NSString * days;
@property (nullable, nonatomic, copy) NSString * mindate;
@property (nullable, nonatomic, copy) NSString * maxdate;
@property (nullable, nonatomic, copy) NSString * param;
@property (nullable, nonatomic, copy) NSString * ps;
@property (nullable, nonatomic, copy) NSString * pn;
@property (nullable, nonatomic, copy) NSString * sort;

- (instancetype)initWithServiceSearch:(BOOL)isServiceSearch;

@end
NS_ASSUME_NONNULL_END