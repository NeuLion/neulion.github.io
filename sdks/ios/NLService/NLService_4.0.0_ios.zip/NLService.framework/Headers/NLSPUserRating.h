//
//  NLSPUserRating.h
//  NeuLionService
//
//  Created by Chengming on 16/2/24.
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import "NLSPUserRecord.h"

@interface NLSPUserRating : NLSPUserRecord

@property (nonatomic, copy) NSString * rating;

@end
