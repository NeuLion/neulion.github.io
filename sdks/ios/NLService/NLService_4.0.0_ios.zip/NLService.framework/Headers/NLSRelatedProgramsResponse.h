//
//  NLRelatedProgramsResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN

@interface NLSRelatedProgramsResponse : NLSResponse

@property (nullable, nonatomic, strong) NSArray * relatedSimilar;
@property (nullable, nonatomic, strong) NSArray * relatedCategory;
@property (nullable, nonatomic, strong) NSArray * relatedKeyword;

@end
NS_ASSUME_NONNULL_END