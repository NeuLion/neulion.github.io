//
//  NLSSubscriptionItem.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-16.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"

@interface NLSSubscriptionItem : NLSModel

@property (nonatomic, copy) NSString * type;
@property (nonatomic, copy) NSString * name;
@property (nonatomic, copy) NSString * contentId;
@property (nonatomic, copy) NSString * sku;
@property (nonatomic, copy) NSString * purchaseTypeId;
@property (nonatomic, copy) NSString * autoRenew;
@property (nonatomic, copy) NSString * lastBilledDate;
@property (nonatomic, copy) NSString * nextBillDate;
@property (nonatomic, copy) NSString * billedDate;
@property (nonatomic, copy) NSString * accessThrough;
@property (nonatomic, copy) NSString * dateFrom;
@property (nonatomic, strong) NSArray *details;

@end
