//
//  NLDeviceUnlinkRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSDeviceUnlinkRequest : NLSRequest
@property (copy, nullable, nonatomic) NSString     *token;

@property (copy, nullable, nonatomic) NSString     *deviceid;
@property (copy, nullable, nonatomic) NSString     *devicetype;


-(instancetype)initWithToken:(NSString *)token;
-(instancetype)initWithDevice;

@end
NS_ASSUME_NONNULL_END