//
//  NLSGameDetailResponse.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-12-16.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN
@class NLSGame;

@interface NLSGameDetailResponse : NLSResponse
@property (nullable, nonatomic, strong) NLSGame * game;
@end
NS_ASSUME_NONNULL_END