//
//  NLAuthenticationbyUsernamePassword.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSAuthenticationRequest : NLSRequest

@property (copy, nonatomic) NSString     *token;

-(instancetype)initWithToken:(NSString *)token;
@end
NS_ASSUME_NONNULL_END