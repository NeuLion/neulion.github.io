//
//  NLSClient.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSCoreClient.h"

#import "NLSProgramDetailsRequest.h"
#import "NLSProgramDetailsResponse.h"
#import "NLSPublishPointRequest.h"
#import "NLSPublishPointResponse.h"
#import "NLSCategoryProgramsRequest.h"
#import "NLSCategoryProgramsResponse.h"
#import "NLSGameScheduleRequest.h"
#import "NLSGameScheduleResponse.h"
#import "NLSSessionCheckRequest.h"
#import "NLSSessionCheckResponse.h"

#import "NLSRegistrationRequest.h"
#import "NLSRegistrationResponse.h"
#import "NLSDeviceLinkRequest.h"
#import "NLSDeviceLinkResponse.h"
#import "NLSDeviceUnlinkRequest.h"
#import "NLSDeviceUnlinkResponse.h"
#import "NLSEndSessionRequest.h"
#import "NLSEndSessionResponse.h"
#import "NLSPurchaseRequest.h"
#import "NLSPurchaseResponse.h"
#import "NLSGameDetailRequest.h"
#import "NLSGameDetailResponse.h"
#import "NLSSubscriptionsRequest.h"
#import "NLSSubscriptionsResponse.h"
#import "NLSAuthenticationRequest.h"
#import "NLSAuthenticationResponse.h"
#import "NLSSendResetPasswordEmailResponse.h"
#import "NLSAuthenticateReceiptRequest.h"
#import "NLSAuthenticateReceiptResponse.h"

NS_ASSUME_NONNULL_BEGIN
typedef void (^NLSClientCompletionBlock)(BOOL succeeded, NSError * __nullable error);
typedef void (^NLSStreamUrlChangeCallbackBlock)(NSString * __nullable url);

/**
 *	@brief	NLSClient is the main utility class for calling the NeuLion APIs conveniently.
 */
@interface NLSClient : NLSCoreClient

/**
 *  @brief  Set up the client by setting the app key. The client would get request required information for initialization.
 *
 *  @param appKey    The app key NeuLion provides for your app.
 *  @param completion   The block that would be invoked when the setup is completed.
 */
+(void)setupWithAppKey:(NSString* __nullable)appKey completion:(__nullable NLSClientCompletionBlock)completion;


/**
 *  @brief  Create a new instance of NLSClient class.
 *
 *  @return A new instance.
 */
+(instancetype)newInstance;


/**
 *  @brief  Create a singleton of NLSClient class.
 *
 *  @return A singleton.
 */
+(instancetype)sharedInstance;


#pragma mark - Media Content Services

/**
 *  @brief  Call the Publish Point API with synchronous request. The response object is retured directly.
 *
 *  @param request A NLSPublishPointRequest object.
 *
 *  @return A NLSPublishPointResponse object.
 */
- (NLSPublishPointResponse *)getPublishPointWithSyncRequest: (NLSPublishPointRequest *)request;

/**
 *  @brief  Call the Publish Point API with synchronous request and the session timeout block. The response object is retured directly.
 *
 *  If you want to get publish point for Adobe Pass, you should call this method and pass in the session timeout block as callback. If <useAdobePassSessionPolling>true</useAdobePassSessionPolling> exists in the config file, the session poll will start with interval defined in <sessionPollIntervall> in the config file after the Publish Point API call got valid response.
 *
 *  @param request A NLSPublishPointRequest object.
 *  @param sessionTimeoutBlock  The block that would be executed with NLSSessionCheckResponse object when the client gets the session timeout response from the Session Check API request from server.
 *
 *  @return A NLSPublishPointResponse object.
 */
- (NLSPublishPointResponse *)getPublishPointWithSyncRequest: (NLSPublishPointRequest *)request sessionTimeout:(void (^) (NLSSessionCheckResponse *response))sessionTimeoutBlock;

/**
 *  @brief  Call the Publish Point API with asynchronous request. The response object is returned in the block callback method.
 *
 *  @param request    A NLSPublishPointRequest object.
 *  @param completion The block that would be executed with NLSPublishPointResponse object when the client gets the response of the API request from server.
 */
- (void)getPublishPointWithAsyncRequest: (NLSPublishPointRequest *)request completion:(void (^)(NLSPublishPointResponse *response))completion;

/**
 *  @brief  Call the Publish Point API with asynchronous request. The response object is returned in the block callback method.
 *
 *  If you want to get publish point for Adobe Pass, you should call this method and pass in the session timeout block as callback. If <useAdobePassSessionPolling>true</useAdobePassSessionPolling> exists in the config file, the session poll will start with interval defined in <sessionPollIntervall> in the config file after the Publish Point API call got valid response.
 *
 *  @param request    A NLSPublishPointRequest object.
 *  @param completion The block that would be executed with NLSPublishPointResponse object when the client gets the response of the API request from server.
 *  @param sessionTimeoutBlock  The block that would be executed with NLSSessionCheckResponse object when the client gets the session timeout response from the Session Check API request from server.
 */
- (void)getPublishPointWithAsyncRequest: (NLSPublishPointRequest *)request completion:(void (^)(NLSPublishPointResponse *response))completion sessionTimeout:(void (^) (NLSSessionCheckResponse *response))sessionTimeoutBlock;

/**
 *  @brief  The method provides a way to generate security token base on your local security key.
 *
 *  @param localKey A local key.
 *
 *  @return security token.
 */
- (NSString *)getPublishPointEncryptKeyWithLocalKey:(NSString *)localKey;

/**
 *  @brief  Call the Program Details API with synchronous request. The response object is retured directly.
 *
 *  @param request A NLSProgramDetailsRequest object.
 *
 *  @return A NLSProgramDetailsResponse object.
 */
- (NLSProgramDetailsResponse *)getProgramDetailsWithSyncRequest:(NLSProgramDetailsRequest *)request;

/**
 *  @brief  Call the Program Details API with asynchronous request. The response object is returned in the block callback method.
 *
 *  @param request    A NLSProgramDetailsRequest object.
 *  @param completion The block that would be executed with NLSProgramDetailsResponse object when the client gets the response of the API request from server.
 */
- (void)getProgramDetailsWithAsyncRequest:(NLSProgramDetailsRequest *)request completion:(void (^)(NLSProgramDetailsResponse *response))completion;

/**
 *  @brief  Call the Category Programs API with synchronous request. The response object is retured directly.
 *
 *  @param request A NLSCategoryProgramsRequest object.
 *
 *  @return A NLSCategoryProgramsResponse object.
 */
- (NLSCategoryProgramsResponse *)getCategoryProgramsWithSyncRequest:(NLSCategoryProgramsRequest *)request;

/**
 *  @brief  Call the Category Programs API with asynchronous request. The response object is returned in the block callback method.
 *
 *  @param request    A NLSCategoryProgramsRequest object.
 *  @param completion The block that would be executed with NLSCategoryProgramsResponse object when the client gets the response of the API request from server.
 */
- (void)getCategoryProgramsWithAsyncRequest:(NLSCategoryProgramsRequest *)request completion:(void (^)(NLSCategoryProgramsResponse *response))completion;


+ (NSString *)getJSSESSIONID;

#pragma mark - Game Content Services


/**
 *  @brief  Call the Game Detail API with synchronous request. The response object is retured directly.
 *
 *  @param request A NLSGameDetailRequest object.
 *
 *  @return A NLSGameDetailResponse object.
 */
- (NLSGameDetailResponse *)getGameDetailWithSyncRequest:(NLSGameDetailRequest *)request;

/**
 *  @brief Call the Game Detail API with asynchronous request. The response object is returned in the block callback method.
 *
 *  @param request    A NLSGameDetailResponse object.
 *  @param completion The block that would be executed with NLSGameDetailResponse object when the client gets the response of the API request from server.
 */
- (void)getGameDetailWithAsyncRequest:(NLSGameDetailRequest *)request completion:(void (^)(NLSGameDetailResponse *response))completion;

/**
 *  @brief  Call the Game Schedule API with synchronous request. The response object is retured directly.
 *
 *  @param request A NLSGameScheduleRequest object.
 *
 *  @return A NLSGameScheduleResponse object.
 */
- (NLSGameScheduleResponse *)getGameScheduleWithSyncRequest:(NLSGameScheduleRequest *)request;

/**
 *  @brief Call the Category Programs API with asynchronous request. The response object is returned in the block callback method.
 *
 *  @param request    A NLSGameScheduleResponse object.
 *  @param completion The block that would be executed with NLSGameScheduleResponse object when the client gets the response of the API request from server.
 */
- (void)getGameScheduleWithAsyncRequest:(NLSGameScheduleRequest *)request completion:(void (^)(NLSGameScheduleResponse *response))completion;


#pragma mark - Registration Services

/**
 *	@brief	Call the Registration API with synchronous request. The response object is retured directly.
 *
 *	@param 	request 	A NLSRegistrationRequest object.
 *
 *	@return	A NLSRegistrationResponse object.
 */
-(NLSRegistrationResponse *)registerWithSyncRequest:(NLSRegistrationRequest *)request;

/**
 *	@brief	Call the Registration API with asynchronous request. The response object is returned in the block callback method.
 *
 *	@param 	request 	A NLSRegistrationRequest object.
 *  @param completion The block that would be executed with NLSRegistrationResponse object when the client gets the response of the API request from server.
 */
-(void)registerWithAsyncRequest:(NLSRegistrationRequest *)request completion:(void (^)(NLSRegistrationResponse *response))completion;

/**
 *	@brief	Call the Ret Password API with synchronous request. The response object is retured directly.
 *
 *	@param email 	email
 *
 *	@return	A NLSSendResetPasswordEmailResponse object
 */
-(NLSSendResetPasswordEmailResponse *)resetPasswordSyncWithEmail:(NSString *)email;

/**
 *	@brief	Call Ret Password API with asynchronous request. The response object is returned in the block callback method.
 *
 *	@param email 	email
 *
 *  @param completion The block that would be executed with NLSSendResetPasswordEmailResponse object when the client gets the response of the API request from server.
 */
-(void)resetPasswordAsyncWithEmail:(NSString *)email completion:(void (^)(NLSSendResetPasswordEmailResponse *response))completion;


#pragma mark - Authentication Services

/**
 *	@brief	Check the device linking and authentication state.
 *
 *	@return	YES or NO indicating that if there is valid session and the current device linked after authentication.
 */
-(BOOL)isDeviceLinked;

/**
 *	@brief	Check the device linking and authentication state.
 *
 *	@return	YES or NO indicating that if there is valid session and the current device linked after authentication.
 */
-(BOOL)isAuthenticated;

/**
 *	@brief	Check the device linking and hasSubcription state.
 *
 *	@return	YES or NO
 */
-(BOOL)hasSubcription;

/**
 *	@brief	Get current authentication info
 *
 *	@return	A NLSAuthenticationInfo object
 */
-(NLSAuthenticationInfo *)getUserInfo;

/**
 *	@brief	Call the Device Link API with synchronous request. The response object is retured directly.
 *
 *	@param username 	Link username
 *	@param username 	Link password
 *
 *	@return	A NLSDeviceLinkResponse object
 */
-(NLSDeviceLinkResponse *)linkDeviceSyncWithUsername:(NSString *)username password:(NSString *)password;

/**
 *	@brief	Call the Device Link API with asynchronous request. The response object is returned in the block callback method.
 *
 *	@param username 	Link username
 *	@param username 	Link password
 *  @param completion The block that would be executed with NLSDeviceLinkResponse object when the client gets the response of the API request from server.
 */
-(void)linkDeviceAsyncWithUsername:(NSString *)username password:(NSString *)password completion:(void (^)(NLSDeviceLinkResponse *response))completion;

/**
 *	@brief	Call the Device Link API with asynchronous request. The response object is returned in the block callback method.
 *
 *	@param receipt 	the receipt for validation
 */
-(NLSAuthenticateReceiptResponse *)linkDeviceSyncWithReceipt:(NSString *)receipt;

/**
 *	@brief	Call the Device Link API with asynchronous request. The response object is returned in the block callback method.
 *
 *	@param receipt the receipt for validation
 *  @param completion The block that would be executed with NLSAuthenticateReceiptResponse object when the client gets the response of the API request from server.
 */
-(void)linkDeviceAsyncWithReceipt:(NSString *) receipt completion:(void (^)(NLSAuthenticateReceiptResponse *response))completion;


/**
 *	@brief	Call the Device Link API with synchronous request. The response object is returned in the block callback method.
 *
 *	@param clientId 	Link clientId
 *	@param username 	Link username
 *	@param password 	Link password
 */
- (NLSDeviceLinkResponse *)linkDeviceSyncWithClientId:(NSString *)clientId username:(NSString *)username password:(NSString *)password;

/**
 *	@brief	Call the Device Link API with asynchronous request. The response object is returned in the block callback method.
 *
 *	@param clientId 	Link clientId
 *	@param username 	Link username
 *	@param password 	Link password
 *  @param completion The block that would be executed with NLSDeviceLinkResponse object when the client gets the response of the API request from server.
 */
- (void)linkDeviceAsyncWithClientId:(NSString *)clientId username:(NSString *)username password:(NSString *)password completion:(void (^)(NLSDeviceLinkResponse *response))completion;

/**
 *	@brief	Call the Authentication API with synchronous request. The response object is retured directly.
 *
 *	@return	A NLSAuthenticationResponse object
 */
-(NLSAuthenticationResponse *)authenticateSync;

/**
 *	@brief	Call the Authentication API with asynchronous request. The response object is returned in the block callback method.
 *
 *  @param completion The block that would be executed with NLSAuthenticationResponse object when the client gets the response of the API request from server.
 */
-(void)authenticateAsyncWithCompletion:(void (^)(NLSAuthenticationResponse *response))completion;

/**
 *	@brief	Call the Device Unlink API with synchronous request. The response object is retured directly.
 *
 *	If the device is linked, this method will get the token previously stored when calling Device Link API and execute Device Unlink By Token API according to the NeuLion Platform Web Services document. If the token has not been stored yet, this method will execute Device Unlink By Device ID API using the current device information automatically.
 *
 *	@return	A NLSDeviceUnlinkResponse object.
 */
-(NLSDeviceUnlinkResponse *)unlinkDeviceSync;

/**
 *	@brief	Call the Device Unlink API with asynchronous request. The response object is returned in the block callback method.
 *
 *  If the device is linked, this method will get the token previously stored when calling Device Link API and execute Device Unlink By Token API according to the NeuLion Platform Web Services document. If the token has not been stored yet, this method will execute Device Unlink By Device ID API using the current device information automatically.
 *
 *  @param completion The block that would be executed with NLSDeviceUnlinkResponse object when the client gets the response of the API request from server.
 */
-(void)unlinkDeviceAsyncWithCompletion:(void (^)(NLSDeviceUnlinkResponse *response))completion;


#pragma mark - Purchase Services

/**
 *	@brief	Call the Purchase API with synchronous request. The response object is retured directly.
 *
 *	@param 	request 	A NLSPurchaseRequest object.
 *
 *	@return	A NLSPurchaseResponse object.
 */
-(NLSPurchaseResponse *)purchaseWithSyncRequest:(NLSPurchaseRequest *)request;

/**
 *	@brief	Call the Purchase API with asynchronous request. The response object is returned in the block callback method.
 *
 *	@param 	request 	A NLSPurchaseRequest object.
 *  @param completion The block that would be executed with NLSPurchaseResponse object when the client gets the response of the API request from server.
 */
-(void)purchaseWithAsyncRequest:(NLSPurchaseRequest *)request completion:(void (^)(NLSPurchaseResponse *response))completion;

/**
 *	@brief	Get setting value from the configuration file.
 *
 *	@param 	nlid 	The nlid attribute in the setting element. e.g. <setting nlid="nl.service.gaa" enable="true">.
 *  @param  key     The sub element key of setting element. e.g. <setting nlid="nl.service.gaa" enable="true"> <gaa>UA-47826941-14</gaa> </setting>, the key is "gaa".
 *
 *	@return The value of sub element key in setting element. e.g. <setting nlid="nl.service.gaa" enable="true"> <gaa>UA-47826941-14</gaa> </setting>, the value is "UA-47826941-14".

 */
- (NSString *)getNLSSettingWithNlid:(NSString *)nlid forKey:(NSString *)key;

/**
 *	@brief	Call Publish Point API for live stream URL of linear channel with EPG based GEO blackout logic.
 *
 *  In some cases, the content provider wants to restrict the content in a live channel stream in more accurate way. EPG based GEO blackout logic is one of the solutions. For example, the content provider wants to block one program in the live channel for some areas and substitute the program with other content, they can provide an EPG feed in which the program item contains the substitution content ID that we can use to get the publish point URL for it. The EPG feed may change dynamically and time flies, so current program of the channel will change and the streamUrlChangeCallbackBlock may be invoked 1 or multiple times with the stream URL or nil if error occurs or no access. The streamUrlChangeCallbackBlock will only be invoked when the stream URL changes among nil, live channel stream URL and blackout substitution content stream URL.
 *
 *	@param 	request 	A NLSPublishPointRequest object initialized for requesting channel type publish point.
 *  @param  streamUrlChangeCallbackBlock    The block that would be executed with the stream URL string when the stream URL changes during playing the live channel content.
 */
- (void)getChannelPublishPointWithAsyncRequest:(NLSPublishPointRequest *)request streamUrlChangeCallback:(__nullable NLSStreamUrlChangeCallbackBlock)streamUrlChangeCallbackBlock;

/**
 *	@brief	Stop the EPG based GEO blackout logic. This method should be called when closing the video player or switching to play another channel.
 */
- (void)stopChannelPublishPointBlackoutChecking;


/**
 *@brief Call the Subscriptions API with synchronous request. The response object is returned directly.
 *@param request 	A NLSSubscriptionsRequest object.
 *@return	A NLSSubscriptionsResponse object
 */
-(NLSSubscriptionsResponse *)getSubscriptionsWithSyncRequest:(NLSSubscriptionsRequest *)request;

/**
 *@brief	Call the Subscription API with asynchronous request. The response object is returned in the block callback method.
 *@param request 	A NLSSubscriptionsRequest object.
 *@param completion The block that would be executed with NLSSubscriptionsResponse object when the client gets the response of the API request from server.
 */
-(void)getSubscriptionsWithAsyncRequest:(NLSSubscriptionsRequest *)request completion:(void (^)(NLSSubscriptionsResponse *response))completion;

/**
 *@brief	Call the session API with asynchronous request. The response object is returned in the block callback method.
 *@param request 	No parameters are required for this call
 *@param completion The block that would be executed and return a NLSSessionCheckResponse object when the client gets the response of the API request from server.
 */
- (void)sessionCheckWithSessionTimeoutBlock:(void (^) (NLSSessionCheckResponse *response))sessionTimeoutBlock;

@end


extern NSString * const NLSSessionTimeoutNotification;


NS_ASSUME_NONNULL_END
