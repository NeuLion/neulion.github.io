//
//  NLSApplyPPVCreditRequest.h
//  NeuLionService
//
//  Created by Chengming on 16/10/12.
//  Copyright © 2016年 NeuLion, Inc. All rights reserved.
//

#import <NLService/NLService.h>
NS_ASSUME_NONNULL_BEGIN
@interface NLSApplyPPVCreditRequest : NLSRequest

@property (nullable, nonatomic, copy) NSString * applycredit;
@property (nullable, nonatomic, copy) NSString * contentId;

@end
NS_ASSUME_NONNULL_END