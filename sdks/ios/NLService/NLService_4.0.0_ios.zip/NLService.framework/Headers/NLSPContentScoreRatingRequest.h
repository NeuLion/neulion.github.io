//
//  NLSPContentScoreRatingRequest.h
//  NeuLionService
//
//  Created by Chengming on 16/2/24.
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import "NLSPersonalizeRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSPContentScoreRatingRequest : NLSPersonalizeRequest

//Updated record after the time in millisecond
@property (nullable, nonatomic, copy) NSString * startTime;
//Updated record before the time, default is now
@property (nullable, nonatomic, copy) NSString * endTime;

@end
NS_ASSUME_NONNULL_END