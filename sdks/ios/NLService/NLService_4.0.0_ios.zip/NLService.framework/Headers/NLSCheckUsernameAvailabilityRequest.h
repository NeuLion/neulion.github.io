//
//  NLCheckUsernameAvailabilityRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN

@interface NLSCheckUsernameAvailabilityRequest : NLSRequest

/**
 *  Username to check if available.
 */
@property (copy, nonatomic) NSString *username;

/**
 *  Initialization method specifying username.
 *
 *  @param username The user name to be checked.
 *
 *  @return An instance.
 */
-(instancetype)initWithUsername:(NSString *)username;

@end
NS_ASSUME_NONNULL_END