//
//  NLSendActivationEmailRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSSendActivationEmailRequest : NLSRequest
@property (copy, nonatomic) NSString     *username;

-(instancetype)initWithUsername:(NSString *)username;
@end
NS_ASSUME_NONNULL_END