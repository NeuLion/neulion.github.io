//
//  NLEndSessionRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSEndSessionRequest : NLSRequest
@end
NS_ASSUME_NONNULL_END