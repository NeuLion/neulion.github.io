//
//  NLTotalCostRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN

@interface NLSTotalCostRequest : NLSRequest

@property (copy, nullable, nonatomic) NSString *country;
@property (copy, nullable, nonatomic) NSString *state;
@property (copy, nullable, nonatomic) NSString *zip;
@property (copy, nullable, nonatomic) NSString *productid;
@property (copy, nullable, nonatomic) NSString *bundleid;
@property (copy, nullable, nonatomic) NSString *promo;

-(instancetype)initWithProductId:(NSString *)productId;
-(instancetype)initWithBundleId:(NSString *)bundleId;

@end
NS_ASSUME_NONNULL_END