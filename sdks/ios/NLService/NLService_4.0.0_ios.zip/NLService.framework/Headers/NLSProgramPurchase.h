//
//  NLProgramPurchase.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSModel.h"
@class NLSPayPerView;
@class NLSProgramProduct;


@interface NLSProgramPurchase : NLSModel

/** The purchase type string */
@property (nonatomic, copy) NSString * type;

/** The SKU of the purchasing item */
@property (nonatomic, copy) NSString * sku;

/** Name of the program */
@property (nonatomic, copy) NSString * name;

/** Description of the program */
@property (nonatomic, copy) NSString * desc;


@property (nonatomic, copy) NSString * region;

/**
 *  The product information, which is just an abstract concept with price.
 * @see NLSProgramProduct for more information.
 */
@property (nonatomic, strong) NLSProgramProduct * product;

/**
 *  The pay-per-view information
 * @see NLSPayPerView for more information.
 */
@property (nonatomic, strong) NLSPayPerView * ppv;

@end
