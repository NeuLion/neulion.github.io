//
//  NLBillingUpdateRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSBillingUpdateRequest : NLSRequest

@property (copy, nullable, nonatomic) NSString *billing;
@property (copy, nullable, nonatomic) NSString *address1;
@property (copy, nullable, nonatomic) NSString *address2;
@property (copy, nullable, nonatomic) NSString *city;
@property (copy, nullable, nonatomic) NSString *state;
@property (copy, nullable, nonatomic) NSString *zip;
@property (copy, nullable, nonatomic) NSString *country;
@property (copy, nullable, nonatomic) NSString *phone;
@property (copy, nullable, nonatomic) NSString *cardnumber;
@property (copy, nullable, nonatomic) NSString *cardexpmonth;
@property (copy, nullable, nonatomic) NSString *cardexpyear;
@property (copy, nullable, nonatomic) NSString *cardholder;
@property (copy, nullable, nonatomic) NSString *cardtype;


-(instancetype)initWithBilling:(BOOL)billing address1:(NSString *)address1 city:(NSString *)city state:(NSString *)state zip:(NSString *)zip country:(NSString *)country ;

@end
NS_ASSUME_NONNULL_END