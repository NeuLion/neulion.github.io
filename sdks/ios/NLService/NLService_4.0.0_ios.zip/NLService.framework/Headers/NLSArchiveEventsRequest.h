//
//  NLArchiveEventsRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSArchiveEventsRequest : NLSRequest
@property (nullable, nonatomic, copy) NSString * year;
@property (nullable, nonatomic, copy) NSString * ps;
@property (nullable, nonatomic, copy) NSString * pn;
@property (nullable, nonatomic, copy) NSString * sort;
@end
NS_ASSUME_NONNULL_END