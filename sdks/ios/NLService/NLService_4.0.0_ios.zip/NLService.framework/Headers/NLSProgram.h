//
//  NLProgram.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSModel.h"
@class NLSCategory;
@class NLSBlackoutInfo;
@class NLSProgramPurchase;

typedef NS_ENUM(NSInteger, NLSProgramState) {
    NLSProgramStateNone = -1,
    NLSProgramStateUpcoming = 0,
    NLSProgramStateLive = 1,
    NLSProgramStateLiveDVR = 2
};

@interface NLSProgram : NLSModel

/** Unique ID of program */
@property (nonatomic, copy) NSString * programId;

/** Name of program */
@property (nonatomic, copy) NSString * name;

/** Unique SEO name */
@property (nonatomic, copy) NSString * seoName;

/** Program code */
@property (nonatomic, copy) NSString * programCode;

/** Program description */
@property (nonatomic, copy) NSString * programDescription;

/** Program thumbnail */
@property (nonatomic, copy) NSString * image;

/** 
 * Runtime minutes.  If less than 60 minutes, in m:ss format.  Otherwise integer
 * of number of minutes.
 */
@property (nonatomic, copy) NSString * runtime;

/**
 * m:ss
 * h:mm:ss
 */
@property (nonatomic, copy) NSString * runtimeHours;

/**
 *  State of Live program, only exists for live events.
 * @note Possible values: \n
 * 0 – upcoming \n
 * 1 – live \n
 * 2 – DVR live \n
 */
@property (nonatomic, copy) NSString * liveState;

/**
 *  Begin date of Live program, only exist for live events.
 * @note Example: 2013-04-10T00:00:00.000
 */
@property (nonatomic, copy) NSString * beginDateTime;

/**
 *  Begin date with GMT time of Live program, only exist for live events.
 * @note Example: 2013-04-10T00:00:00.000
 */
@property (nonatomic, copy) NSString * beginDateTimeGMT;

/**
 *  End date with GMT time of Live program, only exist for live events.
 * @note Example: 2013-04-10T00:00:00.000
 */
@property (nonatomic, copy) NSString * endDateTimeGMT;

/**
 *  The release date of the VOD program. Only exists for non-live events (VODs)
 * @note Example: 2013-04-10T00:00:00.000
 */
@property (nonatomic, copy) NSString * releaseDate;

/** Location if available */
@property (nonatomic, copy) NSString * location;

/** Venue if available */
@property (nonatomic, copy) NSString * venue;

/** Program External URL */
@property (nonatomic, copy) NSString * extUrl;

/** Program larger size of image */
@property (nonatomic, copy) NSString * bigImage;

/** If sharable will have this element with value of “true” */
@property (nonatomic, copy) NSString * share;

/** If program is purchasable, will have this element with value of “true” */
@property (nonatomic, assign) BOOL purchasable;


@property (nonatomic, copy) NSString * purchaseTypeId;

/**
 * The Geo Blackout information.
 * @see NLSBlackoutInfo for more information.
 */
@property (nonatomic, strong) NLSBlackoutInfo * blackout;

/** Flag to indicate no access to this content */
@property (nonatomic, copy) NSString * noAccess;

/** 
 * Purchase information, only available if no access 
 * @see NLSProgramPurchase for more information.
 */
@property (nonatomic, strong) NSArray * programPurchases;

/**
 * Purchase information, only available if no access
 * @see NLSBundlePurchase for more information.
 */
@property (nonatomic, strong) NSArray * bundlePurchases;

/**
 * Only applies to the aggregate service version.  Each element contains related
 * programs by similar association, category inclusion, and/or keyword association. 
 * See Related Programs section.
 * @see NLSProgram for more information.
 */
@property (nonatomic, strong) NSArray * relatedSimilar;

/**
 * Only applies to the aggregate service version.  Each element contains related
 * programs by similar association, category inclusion, and/or keyword association.
 * See Related Programs section.
 * @see NLSProgram for more information.
 */
@property (nonatomic, strong) NSArray * relatedCategory;

/**
 * Only applies to the aggregate service version.  Each element contains related
 * programs by similar association, category inclusion, and/or keyword association.
 * See Related Programs section.
 * @see NLSProgram for more information.
 */
@property (nonatomic, strong) NSArray * relatedKeyword;

/**
 * If categories parameter was passed in, this element and <category> sub-elements 
 * contain the categories that this program belongs to.  Each <category> has <id>, 
 * <seoName>, and <name>.
 * @see NLSCategory for more information.
 */
@property (nonatomic, strong) NSArray * categories;


@property (nonatomic, copy) NSString * mainProgramId;


@property (nonatomic, copy) NSString * eventId;


@property (nonatomic, strong) NSArray * eventPrograms;


@property (nonatomic, assign) BOOL drm;

/**
 *  Base on the Live State, returns program is Live or not
 *
 *  @return a bool that says whether program is Live or not
 */
- (BOOL)isLiveEvent;


-(NLSProgramState)programStateEnum;

@end
