//
//  NLVideoPublishPointResponse.h
//  NeulionService
//
//  Copyright (c) 2014 Neulion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSPublishPointResponse : NLSResponse

/** publishpoint request returned playback URL */
@property (nullable, copy, nonatomic) NSString     *path;

@property (nullable, copy, nonatomic) NSString     *drmToken;

@end

NS_ASSUME_NONNULL_END
