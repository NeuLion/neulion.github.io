//
//  NLServicesUtil.h
//  NeulionService
//
//  Copyright (c) 2014 Neulion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>

@interface NLSUtil : NSObject

+ (NSString *)serialNumber;

+ (NSString *)deviceTypeNumber;
+ (NSString *)deviceName;
+ (NSString *)userAgent;

+ (NSString *)md5:(NSString *)inputStr;
+ (NSString *)encodeURL:(NSString *)string;

// AES String
+ (NSData *)getAES128EncryptedDataWithStr:(NSString *)inputStr withKey:(NSString *)key;
+ (NSString *)getAES128DecryptedStrWithData:(NSData *)inputData withKey:(NSString *)key;

// AES Data
+ (NSData *)AES128EncryptWithData:(NSData *)data withKey:(NSString *)key;
+ (NSData *)AES128DecryptWithData:(NSData *)data withKey:(NSString *)key;


@end
