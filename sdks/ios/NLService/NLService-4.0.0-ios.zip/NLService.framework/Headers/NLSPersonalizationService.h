//
//  PersonalizationService.h
//  NeuLionService
//
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NLSPSetWatchHistoryRequest.h"
#import "NLSPSetWatchHistoryResponse.h"
#import "NLSPListWatchHistoryRequest.h"
#import "NLSPListWatchHistoryResponse.h"
#import "NLSPDeleteWatchHistoryRequest.h"
#import "NLSPDeleteWatchHistoryResponse.h"
#import "NLSPListContentRequest.h"
#import "NLSPListContentResponse.h"

@interface NLSPersonalizationService : NSObject

+ (NLSPersonalizationService *)sharedService;

- (void)refreshAccessToken;
- (void)cleanAccessToken;

-(void)getWatchHistoryWithAsyncRequest:(NLSPListWatchHistoryRequest *)request completion:(void (^)(NLSPListWatchHistoryResponse *response))completion;

-(void)addWatchHistroyWithAsyncRequest:(NLSPSetWatchHistoryRequest *)request completion:(void (^)(NLSPSetWatchHistoryResponse *response))completion;

-(void)deleteWatchHistoryWithAsyncRequest:(NLSPDeleteWatchHistoryRequest *)request completion:(void (^)(NLSPDeleteWatchHistoryResponse *response))completion;

-(void)getContentByIdsWithAsyncRequest:(NLSPListContentRequest *)request completion:(void (^)(NLSPListContentResponse *response))completion;

@end
