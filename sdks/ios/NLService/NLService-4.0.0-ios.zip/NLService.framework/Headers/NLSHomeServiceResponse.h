//
//  NLHomeResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSHomeServiceResponse : NLSResponse

@property (nullable, nonatomic, strong) NSArray * navigationItems;
@property (nullable, nonatomic, strong) NSArray * dynamicLead;
@property (nullable, nonatomic, strong) NSArray * liveEvents;
@property (nullable, nonatomic, strong) NSArray * menus;
@property (nullable, nonatomic, strong) NSArray * sports;
@property (nullable, nonatomic, strong) NSArray * teams;
@property (nullable, nonatomic, strong) NSArray * categoryFilters;
@property (nullable, nonatomic, strong) NSArray * categoryStructure;

@end
NS_ASSUME_NONNULL_END