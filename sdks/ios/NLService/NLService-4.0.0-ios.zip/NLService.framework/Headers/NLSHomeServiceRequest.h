//
//  NLHomeRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSHomeServiceRequest : NLSRequest

@property (nullable, nonatomic, strong) NSString * nosports;
@property (nullable, nonatomic, strong) NSString * nocatstruct;
@property (nullable, nonatomic, strong) NSString * noteams;

-(void)enableNosports;
-(void)enableNocatstruct;
-(void)enableNoteams;

@end
NS_ASSUME_NONNULL_END