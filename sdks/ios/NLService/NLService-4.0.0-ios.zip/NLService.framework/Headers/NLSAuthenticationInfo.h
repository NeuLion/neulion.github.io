//
//  NLSAuthenticationInfo.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-15.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"

@interface NLSAuthenticationInfo : NLSModel

@property (nonatomic, copy) NSString * username;
@property (nonatomic, copy) NSString * firstName;
@property (nonatomic, copy) NSString * hasSubscription;
@property (nonatomic, copy) NSString * hasFutureSubscription;
@property (nonatomic, copy) NSString * isVIP;
@property (nonatomic, copy) NSString * token;
@property (nonatomic, copy) NSString * trackUsername;

@end
