//
//  NLSBilling.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-15.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"
@class NLSCreditCard;
@class NLSBillingAddress;
@class NLSYearRange;
@class NLSOptionItem;

@interface NLSBilling : NLSModel

@property (nonatomic, strong) NSArray           * states;
@property (nonatomic, strong) NSArray           * countries;
@property (nonatomic, strong) NSArray           * cardTypes;
@property (nonatomic, strong) NLSYearRange      * cardYear;
@property (nonatomic, strong) NLSBillingAddress * billingAddress;
@property (nonatomic, copy)   NSString          * phone;
@property (nonatomic, strong) NLSCreditCard     * card;

@end
