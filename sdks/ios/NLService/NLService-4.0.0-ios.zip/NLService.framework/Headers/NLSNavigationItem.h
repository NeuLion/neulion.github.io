//
//  NLNavigationItem.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSModel.h"
#import "NLSCategory.h"

@interface NLSNavigationItem : NLSModel

@property (nonatomic, assign) NSInteger type;
@property (nonatomic, copy) NSString * typeId;
@property (nonatomic, copy) NSString * name;
@property (nonatomic, copy) NSString * link;
@property (nonatomic, strong) NLSCategory * category;
@property (nonatomic, strong) NSArray * programs;
@property (nonatomic, strong) NSArray * games;

@end
