//
//  NLSTotalCostInfo.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-15.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"

@interface NLSTotalCostInfo : NLSModel

@property (copy, nonatomic) NSString *cost;
@property (copy, nonatomic) NSString *discount;
@property (copy, nonatomic) NSString *promoname;
@property (copy, nonatomic) NSString *recurring;
@property (copy, nonatomic) NSString *tax;
@property (copy, nonatomic) NSString *total;
@property (copy, nonatomic) NSString *currency;

@end
