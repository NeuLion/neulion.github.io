//
//  NLPPV.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSModel.h"

@interface NLSPayPerView : NLSModel

/** Program ID that could be purchased via ppv */
@property (nonatomic, copy) NSString * ppvId;

/** The name that is usually used for displaying on the purchase page. */
@property (nonatomic, copy) NSString * name;

@end
