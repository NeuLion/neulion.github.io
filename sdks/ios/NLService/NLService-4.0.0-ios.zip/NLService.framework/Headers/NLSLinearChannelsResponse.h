//
//  NLLinearChannelsResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN

@interface NLSLinearChannelsResponse : NLSResponse
/**
 *  The current server date timestamp.
 */
@property (nullable, nonatomic, copy) NSString *currentDate;
/**
 *  The time zone offset of server time from UTC.
 */
@property (nullable, nonatomic, copy) NSString *tzOffset;
/**
 *  Array of NLSChannel objects.
 */
@property (nullable, nonatomic, strong) NSArray *channels;

@end
NS_ASSUME_NONNULL_END