//
//  NLLinearChannelResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN

@class NLSBlackoutInfo;

@interface NLSLinearChannelResponse : NLSResponse
/**
 *  Linear channel ID.
 */
@property (nullable, copy, nonatomic) NSString *channelId;
/**
 *  Linear channel SEO name.
 */
@property (nullable, copy, nonatomic) NSString *seoName;
/**
 *  Linear channel name.
 */
@property (nullable, copy, nonatomic) NSString *name;
/**
 *  Linear channel description.
 */
@property (nullable, copy, nonatomic) NSString *channelDescription;
/**
 *  Flag indicating if channel has EPG feed.
 * @note return value is true/false.
 */
@property (nullable, copy, nonatomic) NSString *epg;
/**
 *  Linear channel external ID that is from other system.
 */
@property (nullable, copy, nonatomic) NSString *extId;
/**
 *  Flag indicating if the user has access to the content.
 * @note return value is true/flase.
 */
@property (nullable, copy, nonatomic) NSString *noAccess;
/**
 *  If linear channel is blacked out, it will not be nil and will contain blackout information.
 */
@property (nullable, strong, nonatomic) NLSBlackoutInfo *blackout;

@end
NS_ASSUME_NONNULL_END