//
//  NLSPUserPersonalization.h
//  NeuLionService
//
//  Created by Chengming on 16/2/24.
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import "NLSPUserRecord.h"

@interface NLSPUserPersonalization : NLSPUserRecord

@property (nonatomic, assign) BOOL favorite;
@property (nonatomic, assign) BOOL recommended;
@property (nonatomic, copy) NSString * rating;
@property (nonatomic, copy) NSString * completed; //playtimes
@property (nonatomic, assign) BOOL playlist;

@end
