//
//  NLSPHideRecommendedResponse.h
//  NeuLionService
//
//  Created by Chengming on 16/2/24.
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import "NLSPersonalizeResponse.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSPHideRecommendedResponse : NLSPersonalizeResponse

@end
NS_ASSUME_NONNULL_END