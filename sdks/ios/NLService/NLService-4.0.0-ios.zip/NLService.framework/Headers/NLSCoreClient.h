//
//  NLServicesClient.h
//  NeulionService
//
//  Copyright (c) 2014 Neulion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSRequest.h"
#import "NLSResponse.h"

NS_ASSUME_NONNULL_BEGIN

@protocol NLSCoreClientDelegate <NSObject>
-(void)nlServiceClient:(id)client didGetReponse:(NLSResponse *)response request:(NLSRequest *)request;
@end

/** The core client class providing basic HTTP web service request and response handling */
@interface NLSCoreClient : NSObject{
}

/** API server URL leading with http:// */
@property (copy, nonatomic,nullable) NSString *serverUrl;

/** API server URL leading with https://  */
@property (copy, nonatomic,nullable) NSString *serverSecureUrl;

@property (copy, nonatomic,nullable) NSString *personalizationServerUrl;

@property (strong, nonatomic,nullable) NLSRequest *nlServiceRequest;
@property (weak, nonatomic,nullable) id<NLSCoreClientDelegate> delegate;

/**
 *  Set up the client by setting the API server URLs directly.
 *
 *  @param serverURL       API server URL leading with http://
 *  @param serverSecureURL API server URL leading with https://
 */
+(void)setupWithServerURL:(NSString *)serverURL andServerSecureURL:(NSString *)serverSecureURL;


+(void)setupWithServerURL:(NSString *)serverURL serverSecureURL:(NSString *)serverSecureURL andPersonalizationServerURL:(nullable NSString *)personalizationServerURL;

/**
 *  @brief  Set the name of plist file defining the custom relationship mapping to override the original relationship mapping defined in the response classes.
 *  The custom relationship mapping will be used to override original relationship mapping defined in the response classes, so that slight response data structure changes would not result in creating sub classes of the original request, response and model classes. It is an approach to increase flexibility to the NLService architecture.
 *  @param  plistName   the name of custom relationship mapping plist file.
 */
+(void)setCustomRelationshipMappingWithPlistName:(NSString *)plistName;

/**
 *	@brief	Register sub class for model classes definded in NLService framework. By this way, you can take minimun efforts to extend the model classes taking the advantages of internal auto parsing mechanism.
 *
 *	@param 	subClassName 	The sub class name
 *	@param 	baseCalssName 	The base class name
 */
+(void)registerModelSubClassName:(NSString *)subClassName forBaseClassName:(NSString *)baseClassName;


/**
 *  Create a new instance of NLSCoreClient class and set the delegate.
 *
 *  @param delegate The object that acts as the delegate of the new NLSClient instance.
 *
 *  @return A new instance.
 */
+(instancetype)newInstanceWithDelegate:(nullable id<NLSCoreClientDelegate>)delegate;

/**
 *  Initilize a instance with delegate
 *
 *  @param delegate A delegate object conforming protocol NLSCoreClientDelegate
 *
 *  @return The initialized instance.
 */
-(instancetype)initWithDelegate:(nullable id<NLSCoreClientDelegate>)delegate;

/**
 *  Turn logging on for all the client instance.
 */
+ (void)turnLoggingOn;

/**
 *  Turn logging off for all the client instance.
 */
+ (void)turnLoggingOff;

/**
 *  Set request validate secure certificate
 *
 *  @param default YES
 *
 */
+ (void)setValidatesSecureCertificate:(BOOL)flag;

/**
 *  Set offline mode
 *
 *  @param default NO
 *
 */
+ (void)supportOfflineMode:(BOOL)flag;

/**
 *  Execute the API with synchronous request, the response object is retured directly.
 *
 *  @param request An NLSRequest object.
 *
 *  @return an NLSResponse object.
 *
 *  @see NLSRequest for more information
 *  @see NLSResponse for more information
 */
-(NLSResponse *)executeWithSynchronousRequest:(NLSRequest *)request;

/**
 *  Execute the API with asynchronous request,  need to register the callback
 *  nlServiceClient:didGetReponse:request: to get the response object
 *
 *  @param request An NLSRequest object.
 */
-(void)executeWithAsynchronousRequest:(NLSRequest *)request;

/**
 *  Execute the API with asynchronous request
 *
 *  @param request An NLSRequest object.
 *
 *  @param completion The block that would be executed with NLSResponse object when 
 *   the client gets the response of the API request from server.
 *
 *  @see NLSRequest for more information
 *  @see NLSResponse for more information
 */
-(void)executeWithAsynchronousRequest:(NLSRequest *)request completion:(__nullable NLServiceCompletionBlock)completion;

/**
 *  Cancel the asynchronous request
 */
-(void)cancelRequest;

@end


NS_ASSUME_NONNULL_END

