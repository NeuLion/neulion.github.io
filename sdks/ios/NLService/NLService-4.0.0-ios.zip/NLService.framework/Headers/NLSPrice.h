//
//  NLPrice.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSModel.h"

@interface NLSPrice : NLSModel

/** The currency name */
@property (nonatomic, copy) NSString * currency;

/** The amount of price */
@property (nonatomic, assign) float amount;

/** The display string. The currency symbol is HTML encoded. */
@property (nonatomic, copy) NSString * display;

@property (nonatomic, copy) NSString * region;

@property (nonatomic, assign) float amountUSD;

@end
