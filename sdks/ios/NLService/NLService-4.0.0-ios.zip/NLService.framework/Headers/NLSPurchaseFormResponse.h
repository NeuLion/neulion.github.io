//
//  NLPurchaseFormResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN
@class NLSYearRange;
@class NLSOptionItem;
@class NLSBillingAddress;
@class NLSCreditCard;

@interface NLSPurchaseFormResponse : NLSResponse

@property (copy, nullable, nonatomic) NSMutableArray      *states;
@property (copy, nullable, nonatomic) NSMutableArray      *countries;
@property (copy, nullable, nonatomic) NSMutableArray      *cardTypes;
@property (copy, nullable, nonatomic) NSString            *purchasableItem;
@property (copy, nullable, nonatomic) NSString            *phone;
@property (nullable, nonatomic, strong) NLSBillingAddress *billingAddress;
@property (nullable, nonatomic, strong) NLSYearRange      *cardYear;
@property (nullable, nonatomic, strong) NLSCreditCard     *card;

@end
NS_ASSUME_NONNULL_END