//
//  NLSPopularRequest.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-8-12.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSPopularRequest : NLSRequest

@property (nonatomic, copy) NSString * count;

- (instancetype)initWithCount:(NSString *)count;

@end
NS_ASSUME_NONNULL_END