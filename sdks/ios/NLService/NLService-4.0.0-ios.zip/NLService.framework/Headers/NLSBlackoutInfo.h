//
//  NLBlackoutInfo.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSModel.h"

@interface NLSBlackoutInfo : NLSModel

/**
 * If program is blacked out, will contain <isDeny>true</isDeny> if blacked out was
 * due to being in a denied region.  If <isDeny> doesn’t exist, blackout was due to 
 * not being in a whitelist region.
 */
@property (nonatomic, assign) BOOL isDeny;

/**
 * blackoutDescription list of countries. Either list of denied countries or allowed
 * countries, based on <isDeny>.
 */
@property (nonatomic, copy) NSString * blackoutDescription;


@property (nonatomic, copy) NSString * bostation;

@end
