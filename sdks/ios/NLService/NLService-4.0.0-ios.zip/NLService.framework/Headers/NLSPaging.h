//
//  NLProgramPaging.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSModel.h"

@interface NLSPaging : NLSModel

/** The count of the records. */
@property (nonatomic, assign) NSUInteger count;

/** The page number. The default value is 1. The page number starts from 1. */
@property (nonatomic, assign) NSUInteger pageNumber;

/** The count of the pages. */
@property (nonatomic, assign) NSUInteger totalPages;

@end
