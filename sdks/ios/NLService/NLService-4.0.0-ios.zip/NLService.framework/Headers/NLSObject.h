//
//  NLSObject.h
//  NeuLionService
//
//  Created by Robin Kam on 14-12-9.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
@interface NLSObject : NSObject
-(nullable NSArray *)allPropertyNames;
-(nullable NSArray *)namesOfPropertiesOwnedAndInheritedUpToClass:(Class)class;
@end
NS_ASSUME_NONNULL_END
