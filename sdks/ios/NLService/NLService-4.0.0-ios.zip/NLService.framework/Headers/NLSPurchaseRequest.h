//
//  NLPurchaseRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN

@interface NLSPurchaseRequest : NLSRequest

@property (copy, nullable, nonatomic) NSString *receipt;
@property (copy, nullable, nonatomic) NSString *appleautorenew;
@property (copy, nullable, nonatomic) NSString *sku;
@property (copy, nullable, nonatomic) NSString *contentId;
@property (copy, nullable, nonatomic) NSString *ids;
@property (copy, nullable, nonatomic) NSString *promo;
@property (copy, nullable, nonatomic) NSString *autorenew;
@property (copy, nullable, nonatomic) NSString *optinrenew;
@property (copy, nullable, nonatomic) NSString *device;
@property (copy, nullable, nonatomic) NSString *referurl;

-(instancetype)initWithReceipt:(NSString *)receipt andAppleAutoRenew:(BOOL)appleautorenew;

-(instancetype)initWithSku:(NSString *)sku andContentId:(NSString *)contentId;

-(instancetype)initWithSku:(NSString *)sku andBundleContentIds:(NSString *)ids;

@end
NS_ASSUME_NONNULL_END