//
//  NLSUser.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-15.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"

@interface NLSUser : NLSModel

@property (nonatomic, copy) NSString * username;
@property (nonatomic, copy) NSString * firstName;
@property (nonatomic, copy) NSString * lastName;

@end
