//
//  NLRelatedProgramsRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSRelatedProgramsRequest : NLSRequest
@property (nullable, nonatomic, copy) NSString * programId;
@property (nullable, nonatomic, copy) NSString * type;
@property (nullable, nonatomic, copy) NSString * count;

- (instancetype)initWithProgramId:(NSString *)programId;
@end
NS_ASSUME_NONNULL_END