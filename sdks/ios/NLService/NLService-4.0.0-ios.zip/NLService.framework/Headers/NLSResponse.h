//
//  NLServiceResponse.h
//  NeulionService
//
//  Copyright (c) 2014 Neulion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSObject.h"
#import "NLSParsableDataModelProtocol.h"
NS_ASSUME_NONNULL_BEGIN

typedef NSString * _Nullable (^NLSResponseMsgGenerator)(NSString * _Nullable     msgKey);

@interface NLSResponse : NLSObject<NLSParsableDataModelProtocol>

/** Error information about the response */
@property (nonatomic, strong,nullable) NSError *error;

/** The data of the html response. */
@property (nonatomic, strong,nullable) NSData *rawData;

/** The string of the html response. */
@property (nonatomic, copy,nullable) NSString *textContent;


@property (nonatomic, copy,nullable) NSString *resultMsg;

-(instancetype)initWithData:(NSData *)data;
-(instancetype)initWithError:(NSError *)error;
-(nullable NSArray *)allPropertyNames;
-(nullable NSString *)resultMsgKey;

+(void)setMsgGeneratorBlock:(nullable NLSResponseMsgGenerator)block;

@end
NS_ASSUME_NONNULL_END
