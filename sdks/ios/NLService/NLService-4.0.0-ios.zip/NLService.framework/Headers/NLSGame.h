//
//  NLGame.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSModel.h"
#import "NLSTeam.h"
#import "NLSBlackoutInfo.h"

typedef enum : NSUInteger {
    NLSGameUnavailable=-1,
    NLSGameStateUpcoming=0,
    NLSGameStateLive=1,
    NLSGameStateLiveDVR=2,
    NLSGameStateArchive=3,
    NLSGamePendingArchive=4,
} NLSGameState;

typedef enum : NSUInteger {
    NLSGameTBDValueNone=NSUIntegerMax,
    NLSGameTBDValueNecessary=0,
    NLSGameTBDValueTBD=1,
    NLSGameTBDValuePostponed=2,
} NLSGameTBDValue;

typedef enum : NSUInteger {
    NLSGameProgramTypeNone = 0,
    NLSGameProgramTypeBroadcast = 1<<0,
    NLSGameProgramTypeHome = 1<<1,
    NLSGameProgramTypeAway = 1<<2,
    NLSGameProgramTypeCondensed = 1<<3,
    NLSGameProgramTypeCondensedHome = 1<<4,
    NLSGameProgramTypeCondensedAway = 1<<5,
    NLSGameProgramTypeFullContinuousHighlight = 1<<6,
    NLSGameProgramTypeHalftimeHighlight = 1<<7,
    NLSGameProgramTypeAudio = 1<<8,
    NLSGameProgramTypeAudioHome = 1<<9,
    NLSGameProgramTypeAudioAway = 1<<10
} NLSGameProgramType;

@interface NLSGame : NLSModel

/** The unique key of the game. */
@property (nonatomic, copy) NSString * idString;

/** The readable and meaningful game identifier. */
@property (nonatomic, copy) NSString * extId;

@property (nonatomic, copy) NSString * seoName;

/**
 * The start date and time of the game. The default time zone is US Eastern Time.
 *  @note Example: 203-05-07T10:03:28.000
 */
@property (nonatomic, copy) NSString * date;

/** 
 * The GMT start date and time of the game.  
 *  @note Example: 203-05-07T10:03:28.000
 */
@property (nonatomic, copy) NSString * dateTimeGMT;

@property (nonatomic, copy) NSString * endDateTimeGMT;

@property (nonatomic, copy) NSString * round;

@property (nonatomic, copy) NSString * multiCameras;

/** 
 * The logo of the game. Usually the league or the sport icon. 
 * @note Example: images/sports/NCAAFB_s.png
 */
@property (nonatomic, copy) NSString * logo;

/** The sport type of the game.  */
@property (nonatomic, copy) NSString * sportId;

/** The league of the game.  */
@property (nonatomic, copy) NSString * leagueId;

/** The season year. */
@property (nonatomic, copy) NSString * season;

/** A flag indicating if the game is a typical game with home team and away team. */
@property (nonatomic, assign) BOOL isGame;

/** The value means if the game is a free game and if it needs to show purchase 
 *  options for the game. 
 */
@property (nonatomic, assign) BOOL isFree;

/** 
 *  The “tbd” field is for noting a game as TBD.
 *  The meaning of the values are below:
 *  null – default
 *  0 – If Necessary
 *  1 – TBD – To be determined
 *  2 – Postponed
 */
@property (nonatomic, copy) NSString *tbd;

@property (nonatomic, copy) NSString * gameType;

@property (nonatomic, copy) NSString * notes;

/** The away team information. */
@property (nonatomic, strong) NLSTeam * awayTeam;

/** The home team information. */
@property (nonatomic, strong) NLSTeam * homeTeam;

/**  
 *  The integer value should be interpreted into binary format and use bit operation 
 *  comparison to know what the combination of program types the game supports is.
 *
 *  @note Assuming the digit and type mapping is as below: \n
 *      00000000001 = 1 – broadcast \n
 *      00000000010 = 2 – home \n
 *      00000000100 = 4 – away \n
 *      00000001000 = 8 – condensed (broadcast) \n
 *      00000010000 = 16 – condensed home \n
 *      00000100000 = 32 – condensed away \n
 *      00001000000 = 64 – full continuous highlight \n
 *      00010000000 = 128 – halftime highlight \n
 *      00100000000 = 256 – audio \n
 *      01000000000 = 512 – audio home \n
 *      10000000000 = 1024 – audio away \n
 *  If the availablePrograms = 73(00001001001) = 1(00000000001) + 8(00000001000) + 64(00001000000),
 *  it means the game has both Broadcast video (could be live/DVR/archive of the whole game
 *  depending on the game state) and condensed video (VOD) and the Full Highlight video (VOD).
 */
@property (nonatomic, assign) NSUInteger availablePrograms;

/** 
 * The value shows the state of the game
 * @note possilbe values: \n
 * 0 – upcoming \n
 * 1 – live \n
 * 2 – DVR live \n
 * 3 – archive \n
 */
@property (nonatomic, assign) NSUInteger gameState;

/** 
 * The value is from the stats_id column of the GAME table and depending on project. It is usually
 * a part of the stats feed URL that needs to add prefix and suffix to get the full URL of the 
 * stats feed. */
@property (nonatomic, copy) NSString * statsId;

/** 
 * The Geo Blackout information.
 * @see NLSBlackoutInfo for more information.
 */
@property (nonatomic, strong) NLSBlackoutInfo * blackout;

/** 
 * If the property exists in the data feed and the value is true, it means the game is included in
 * a subscription package and the current user account has no access to the game. Note: it is not 
 * the only way for client applications to judge is a user has access to the game. If the value is
 * false or the property does not exist in the data feed, the publish point service would verify if
 * the current account has access to the game video content again.
 */
@property (nonatomic, assign) BOOL noAccess;

@property (nonatomic, copy) NSString * sportName;
@property (nonatomic, copy) NSString * sportGender;
@property (nonatomic, copy) NSString * name;
@property (nonatomic, copy) NSString * leagueName;

@property (nonatomic, copy) NSString * blackoutStations;

@property (nonatomic, copy) NSString * sportHomeFirst;

@property (nonatomic, strong) NSArray * gamePurchases;

@property (nonatomic, strong) NSArray * bundlePurchases;

/**
 *	@brief	This GET method translates the gameState property from NSUInteger value to enumerable value.
 *
 *	@return	The enumerable value correspoding to the current gameState value.
 */
-(NLSGameState)gameStateEnum;

/**
 *	@brief	This GET method translates the availablePrograms property from NSUInteger value to bit mask enumerable value.
 *
 *	@return	The bit mask enumerable value correspoding to the current availablePrograms value.
 */
-(NLSGameProgramType)availableGameProgramTypes;

/**
 *	@brief	This GET method translates the tbd property from NSString value to value to enumerable value.
 *
 *	@return	The enumerable value correspoding to the current tbd value.
 */
-(NLSGameTBDValue)tbdValue;

@end
