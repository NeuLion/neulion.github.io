//
//  NLProgramDetailsResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSResponse.h"
#import "NLSProgram.h"
NS_ASSUME_NONNULL_BEGIN

@interface NLSProgramDetailsResponse : NLSResponse

@property (nullable, strong, nonatomic) NLSProgram *program;

@end
NS_ASSUME_NONNULL_END