//
//  NLSGameDetailRequest.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-12-16.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSGameDetailRequest : NLSRequest {
    NSString *_seoName;
}

@property (nullable, nonatomic, copy) NSString * purchases;

@property (nullable, nonatomic, copy) NSString * downloads;

-(instancetype)initWithSeoName:(NSString *)seoName;

@end
NS_ASSUME_NONNULL_END