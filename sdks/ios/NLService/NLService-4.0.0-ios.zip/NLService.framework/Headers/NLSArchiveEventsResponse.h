//
//  NLArchiveEventsResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
#import "NLSPaging.h"
NS_ASSUME_NONNULL_BEGIN

@interface NLSArchiveEventsResponse : NLSResponse

@property (nullable, nonatomic, strong) NLSPaging * paging;
@property (nullable, nonatomic, copy) NSString * currentYear;
@property (nullable, nonatomic, copy) NSString * minYear;
@property (nullable, nonatomic, copy) NSString * maxYear;
@property (nullable, nonatomic, strong) NSArray * programs;

@end
NS_ASSUME_NONNULL_END