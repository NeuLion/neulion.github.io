//
//  NLGetProductsRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN

@interface NLSGetProductsRequest : NLSRequest

/**
 *  The ID of the program which is wanted to know what options there are for purchasing it.
 */
@property (copy, nullable, nonatomic) NSString *programId;


@end
NS_ASSUME_NONNULL_END