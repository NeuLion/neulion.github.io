//
//  NLGameScheduleRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSGameScheduleRequest : NLSRequest

/** 
 *The sports ID used as a filter field. Usually the abbreviation of sport, e.g.
 *“BK” stands for basketball. 
 */
@property (nullable, nonatomic, copy) NSString * sid;

/** The league ID used as a filter field. Usually the abbreviation of sport league name. */
@property (nullable, nonatomic, copy) NSString * lid;

/** The team ID used as a filter field. Usually the abbreviation of the team name. */
@property (nullable, nonatomic, copy) NSString * tid;

/** The page size for paging. The default value is 10. */
@property (nullable, nonatomic, copy) NSString * ps;

/** The page number. The default value is 1. */
@property (nullable, nonatomic, copy) NSString * pn;

@property (nullable, nonatomic, copy) NSString * lgid;

/**
 * The value should match format yyyy-MM-dd or just equals “today”. If the day is set,
 * query the schedule by day with specified date or today. Used to get a game list in 
 * the past 7 days based on the specified date.
 * @note Example: “2013-05-20” or “today”
 */
@property (nullable, nonatomic, copy) NSString * date;

/**
 * The value should match format yyyy-MM-dd or just equals “today”. If the day is set,
 * query the schedule by day with specified date or today. Used to get an game list on
 * the specified date.
 * @note Example: “2013-05-20” or “today”
 */
@property (nullable, nonatomic, copy) NSString * day;

@property (nullable, nonatomic, copy) NSString * monthly;

/**
 *  The class initialization method that is easy to create and initialize a new instance for requesting schedule by week.
 *
 *  @param date The date.
 *
 *  @return The initialized instance. Used to get a game list in the past 7 days based on
 * the specified date.
 */
- (instancetype)initForWeeklyScheduleWithWeekEndingDate:(NSString *)date;

/**
 *  The class initialization method that is easy to create and initialize a new instance for requesting schedule by day.
 *
 *  @param day The day.
 *
 *  @return The initialized instance. Used to get an game list on the specified date.
 */
- (instancetype)initForDailyScheduleWithDate:(NSString *)day;

- (instancetype)initForMonthlyScheduleWithMonthly:(NSString *)monthly;

@end
NS_ASSUME_NONNULL_END