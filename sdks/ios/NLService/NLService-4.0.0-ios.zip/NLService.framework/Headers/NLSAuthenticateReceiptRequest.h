//
//  NLSAuthenticateReceiptRequest.h
//  NeuLionService
//
//  Created by Chengming on 16/7/14.
//  Copyright © 2016年 NeuLion, Inc. All rights reserved.
//

#import <NLService/NLService.h>

NS_ASSUME_NONNULL_BEGIN
@interface NLSAuthenticateReceiptRequest : NLSRequest

@property (copy, nonatomic) NSString     *receipt;
@property (copy, nullable, nonatomic) NSString     *deviceid;
@property (copy, nullable, nonatomic) NSString     *devicetype;
@property (copy, nullable, nonatomic) NSString     *devicename;

-(instancetype)initWithReceipt:(NSString *)receipt;

@end
NS_ASSUME_NONNULL_END
