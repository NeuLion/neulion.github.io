//
//  NLSUpsellUpdateResponse.h
//  NeuLionService
//
//  Created by Chengming on 9/14/15.
//  Copyright (c) 2015 NeuLion, Inc. All rights reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSUpsellUpdateResponse : NLSResponse

@property (copy, nullable, nonatomic) NSString     *code;
@property (copy, nullable, nonatomic) NSString     *orderId;
@property (copy, nullable, nonatomic) NSString     *orderTotal;
@property (copy, nullable, nonatomic) NSString     *orderTotalDisplay;

@end
NS_ASSUME_NONNULL_END