//
//  NLSCreditCard.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-14.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"

@interface NLSCreditCard : NLSModel

@property (copy, nonatomic) NSString       *number;
@property (copy, nonatomic) NSString       *holderName;
@property (copy, nonatomic) NSString       *type;
@property (copy, nonatomic) NSString       *expMonth;
@property (copy, nonatomic) NSString       *expYear;

@end
