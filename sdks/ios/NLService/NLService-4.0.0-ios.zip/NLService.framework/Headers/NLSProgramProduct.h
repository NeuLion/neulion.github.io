//
//  NLProduct.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSModel.h"
#import "NLSPrice.h"

@interface NLSProgramProduct : NLSModel

/** The product ID */
@property (nonatomic, copy) NSString * productId;

/**
 *  The price information of the product
 * @see NLSPrice for more information.
 */
@property (nonatomic, strong) NLSPrice * price;

@end
