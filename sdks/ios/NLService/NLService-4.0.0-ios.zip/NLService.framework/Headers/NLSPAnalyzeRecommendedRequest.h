//
//  NLSPAnalyzeRecommendedRequest.h
//  NeuLionService
//
//  Created by Chengming on 16/2/24.
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import "NLSPersonalizeRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSPAnalyzeRecommendedRequest : NLSPersonalizeRequest

@property (nullable, nonatomic, copy) NSString * contentId;
@property (nullable, nonatomic, copy) NSString * type;
@property (nullable, nonatomic, copy) NSString * ps;

@end
NS_ASSUME_NONNULL_END