//
//  NLWhatsNewResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN

@class NLSPaging;

@interface NLSWhatsNewResponse : NLSResponse

@property (nullable, nonatomic, strong) NLSPaging * paging;
@property (nullable, nonatomic, strong) NSArray * programs;

@end
NS_ASSUME_NONNULL_END