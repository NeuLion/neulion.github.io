//
//  NLRegistrationFormRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN

@interface NLSRegistrationFormRequest : NLSRequest

@end
NS_ASSUME_NONNULL_END