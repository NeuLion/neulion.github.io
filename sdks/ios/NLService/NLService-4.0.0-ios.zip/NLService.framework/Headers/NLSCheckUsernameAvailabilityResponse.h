//
//  NLCheckUsernameAvailabilityResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSCheckUsernameAvailabilityResponse : NLSResponse

/**
 *  The code representing the result.
 *  @note Supported values are:\n
 *  @b available       - Username is available
 *  @b notavailable    - Username is not available
 */
@property (copy, nullable, nonatomic) NSString *code;

@end
NS_ASSUME_NONNULL_END