//
//  NLCategoryProgramsByIdRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSCategoryProgramsRequest : NLSRequest{
    NSString *_seoName;
}

/** The category ID */
@property (nullable, nonatomic, copy) NSString * categoryId;

/** If category contains programs, programs page size */
@property (nullable, nonatomic, copy) NSString * ps;

/** If category contains programs, programs page number (1 based) */
@property (nullable, nonatomic, copy) NSString * pn;

/** If category contains programs, programs sort order, value is column of PROGRAM view */
@property (nullable, nonatomic, copy) NSString * sort;

/**
 *  Initilize an instance with category ID
 *
 *  @param categoryId The category ID.
 *
 *  @return The initialized instance.
 */
- (instancetype)initWithCategoryId:(NSString *)categoryId;

/**
 *  Initilize an instance with SEO name.
 *
 *  @param seoName SEO name of the category, like "top-ten-highlight".
 *
 *  @return The initialized instance.
 */
- (instancetype)initWithSeoName:(NSString *)seoName;
@end
NS_ASSUME_NONNULL_END