//
//  NLLiveEventsRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSLiveEventsRequest : NLSRequest
@property (nullable, nonatomic, copy) NSString * count;
@end
NS_ASSUME_NONNULL_END