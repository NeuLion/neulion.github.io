//
//  NLSUpsellUpdateRequest.h
//  NeuLionService
//
//  Created by Chengming on 9/14/15.
//  Copyright (c) 2015 NeuLion, Inc. All rights reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSUpsellUpdateRequest : NLSRequest

@property (nullable, nonatomic, copy) NSString * upsell;
@property (nullable, nonatomic, copy) NSString * crosssell;
@property (nullable, nonatomic, copy) NSString * receipt;
@property (nullable, nonatomic, copy) NSString * appleautorenew;
@property (nullable, nonatomic, copy) NSString * device;

@property (nullable, nonatomic, copy) NSString * paytype;
@property (nullable, nonatomic, copy) NSString * googleplayautorenew;
@property (nullable, nonatomic, copy) NSString * googleplaysignature;
@property (nullable, nonatomic, copy) NSString * amazonuid;
@property (nullable, nonatomic, copy) NSString * rokuautorenew;


@end
NS_ASSUME_NONNULL_END