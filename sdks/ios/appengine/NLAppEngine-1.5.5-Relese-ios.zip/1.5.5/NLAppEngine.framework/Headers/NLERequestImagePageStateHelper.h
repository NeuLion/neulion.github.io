//
//  NLERequestImagePageStateHelper.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import "NLERequestPageStateHelper.h"

static NSString * requestSubFontName = nil;
static UIFont * requestSubFont = nil;

@interface NLERequestImagePageStateHelper : NLERequestPageStateHelper

@property (nonatomic, strong) UIFont * subFont;

+ (void)configSubFontName:(NSString *)fontName;
+ (void)configSubTitleFont:(UIFont *)font;

- (void)setTitle:(NSString *)title subTitle:(NSString *)subTitle imageName:(NSString *)imageName forState:(NLERequestPageState)state;
+ (void)setTitle:(NSString *)title subTitle:(NSString *)subTitle imageName:(NSString *)imageName forState:(NLERequestPageState)state;

- (void)setTitle:(NSString *)title subTitle:(NSString *)subTitle imageName:(NSString *)imageName bgImageName:(NSString *)bgImageName forState:(NLERequestPageState)state;
+ (void)setTitle:(NSString *)title subTitle:(NSString *)subTitle imageName:(NSString *)imageName bgImageName:(NSString *)bgImageName forState:(NLERequestPageState)state;


@end
