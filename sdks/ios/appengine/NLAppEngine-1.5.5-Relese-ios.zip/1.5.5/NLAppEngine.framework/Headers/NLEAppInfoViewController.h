//
//  NLEAppInfoViewController.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <UIKit/UIKit.h>
#if TARGET_OS_IOS
#import <MessageUI/MessageUI.h>
#endif

typedef void(^NLEAppInfoWillUpdateUIBlock)(void);

@class NLEAppInfoFooterView;
@protocol NLEAppInfoFooterViewDelegate;

#if TARGET_OS_IOS
typedef NS_ENUM(NSInteger, NLEAppInfoMask) {
    NLEAppInfoVersion              = 1 << 0,
    NLEAppInfoBuildNumber          = 1 << 1,
    NLEAppInfoSerialNumber         = 1 << 2,
    NLEAppInfoHardwareModel        = 1 << 3,
    NLEAppInfoDeviceType           = 1 << 4,
    NLEAppInfoSystemVersion        = 1 << 5,
    NLEAppInfoCarrier              = 1 << 6,
    NLEAppInfoLocation             = 1 << 7,
    NLEAppInfoIPAddress            = 1 << 8,
    NLEAppInfoDeviceToken          = 1 << 9,
    NLEAppInfoLocationService      = 1 << 10,
    NLEAppInfoNotification         = 1 << 11
};

extern NLEAppInfoMask const kAppInfoMasks[12];

#elif TARGET_OS_TV
typedef NS_ENUM(NSInteger, NLEAppInfoMask) {
    NLEAppInfoVersion              = 1 << 0,
    NLEAppInfoBuildNumber          = 1 << 1,
    NLEAppInfoSerialNumber         = 1 << 2,
    NLEAppInfoHardwareModel        = 1 << 3,
    NLEAppInfoDeviceType           = 1 << 4,
    NLEAppInfoSystemVersion        = 1 << 5,
    NLEAppInfoLocation             = 1 << 6,
    NLEAppInfoIPAddress            = 1 << 7,
    NLEAppInfoDeviceToken          = 1 << 8,
    NLEAppInfoLocationService      = 1 << 9,
};

extern NLEAppInfoMask const kAppInfoMasks[10];

#endif




@interface NLEAppInfoViewController : UIViewController <
#if TARGET_OS_IOS
MFMailComposeViewControllerDelegate,
#endif
UITableViewDataSource,
UITableViewDelegate>

@property (strong, nonatomic) UITableView *mainTableView;

@property (assign, nonatomic) NLEAppInfoMask exceptAppInfoMask;
@property (strong, nonatomic) NSDictionary * extendAppInfoDict;
@property (strong, nonatomic) NSDictionary * localizeDictionary;
//[xxx.localizeDictionary setObject:@"your language word" forKey:[NSString stringWithFormat:@"%lu",(unsigned long)NLAppInfoVersion]];

@property (nonatomic, strong) NLEAppInfoFooterView * footerView;

@property (assign, nonatomic) BOOL showFeedbackButton;
@property (assign, nonatomic) BOOL showLogoButton;
@property (copy, nonatomic) NSString * feedBackEmailAddress;
@property (copy, nonatomic) NSString * feedBackEmailSubject;
@property (strong, nonatomic) UIImage * logoImage;
@property (copy, nonatomic) NSString * logoLinkURLString;

@property (strong, nonatomic) UIColor * pageFontColor;
@property (strong, nonatomic) UIColor * pageSendEmailColor;
@property (strong, nonatomic) UIFont * pageFont;
@property (assign, nonatomic) BOOL setDarkBgLogo;

@property (copy, nonatomic) NLEAppInfoWillUpdateUIBlock willUpdateUIBlock;

+ (void)injectFrameworkVersionInfo:(NSString *)version;

@end

@protocol NLEAppInfoFooterViewDelegate <NSObject>

- (void)appInfoFooterViewClickedFeedback:(NLEAppInfoFooterView *)view;
- (void)appInfoFooterViewClickedLogo:(NLEAppInfoFooterView *)view;

@end

@interface NLEAppInfoFooterView : UIView

@property (weak, nonatomic) id<NLEAppInfoFooterViewDelegate> delegate;
@property (strong, nonatomic) UIButton *feedbackButton;
@property (strong, nonatomic) UIButton *logoButton;
- (void)clickedFeedbackAction:(id)sender;
- (void)clickedLogoAction:(id)sender;

- (NLEAppInfoFooterView *)initWithFrame:(CGRect)frame showFeedback:(BOOL)showFeedback showLogo:(BOOL)showLogo;

@end


