//
//  NLMenuItem.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NLEMenuItem : NSObject
@property (nonatomic, copy) NSString * comments;
@property (nonatomic, strong) NSMutableArray * items;

@property (nonatomic, copy) NSString * menuId;
@property (nonatomic, copy) NSString * type;
@property (nonatomic, copy) NSString * title;
@property (nonatomic, copy) NSString * trackingTag;
@property (nonatomic, copy) NSString * desc;
@property (nonatomic, copy) NSString * pImgLocal;
@property (nonatomic, copy) NSString * pImgRemote;
@property (nonatomic, copy) NSString * sImgLocal;
@property (nonatomic, copy) NSString * sImgRemote;
@property (nonatomic, assign) BOOL  enabled;
@property (nonatomic, assign) BOOL  defaulted;
@property (nonatomic, copy) NSString * uiView;
@property (nonatomic, strong) NSDictionary * params;

@property (nonatomic, copy) NSString * fatherTitle;

+(NLEMenuItem *)parseMenuJsonDic:(NSDictionary *)jsonDic;
@end
