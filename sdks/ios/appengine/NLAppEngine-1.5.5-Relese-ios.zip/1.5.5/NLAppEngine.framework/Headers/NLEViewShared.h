//
//  ComViewShared.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NLEViewShared : UIView

- (void)initUI;
- (void)refreshUI;
- (void)cleanViewContent;


@end
