//
//  NLEMediaPlayerManager.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NLEBaseManager.h"

@interface NLEMediaPlayerManager : NLEBaseManager

+ (NLEMediaPlayerManager *)sharedManager;

@end
