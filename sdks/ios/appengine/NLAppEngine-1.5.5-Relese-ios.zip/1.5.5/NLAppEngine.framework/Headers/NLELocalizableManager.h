//
//  NLELocalizableManager.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NLEBaseManager.h"

#define NLLocalizedString(key, comment) \
[[NLELocalizableManager sharedManager] localizableString:(key) placeholder:(comment)]

typedef void(^NLELocalizableUpdateFinishedBlock)(NSError *error);

@interface NLELocalizableManager : NLEBaseManager

@property (nonatomic, strong) NSDictionary * currentLanguageDictionary;

+ (NLELocalizableManager *)sharedManager;
+ (NSString *)getAppDefaultLanguage;
+ (void)saveAppDefaultLanguage:(NSString *)language;
+ (NSString *)getSystemLanguage;
+ (void)setLocalFilePrefix:(NSString *)prefix;
+ (void)setNoMatchToUseLanguage:(NSString *)language; //Defalut en
+ (NSString *)matchSimilarLanguageWithSelectedLanuage:(NSString *)language localLanguageArray:(NSArray *)localLanguageArray;

- (void)updateLocalizableFileWithServerURL:(NSString *)url finished:(NLELocalizableUpdateFinishedBlock)finished;
- (void)updateLocalizableFileWithServerURL:(NSString *)url forLanguage:(NSString *)language finished:(NLELocalizableUpdateFinishedBlock)finished;
- (void)updateLocalizableFileWithData:(NSData *)data finished:(NLELocalizableUpdateFinishedBlock)finished;
- (void)updateLocalizableFileWithData:(NSData *)data forLanguage:(NSString *)language finished:(NLELocalizableUpdateFinishedBlock)finished;

- (NSString *)localizableString:(NSString *)key;
- (NSString *)localizableString:(NSString *)key placeholder:(NSString *)placeholder;

@end

extern NSString * const NLELocalizableNeedGlobalRefreshNotification;
extern NSString * const NLEAppDefaultLanguageChangedNotification;

