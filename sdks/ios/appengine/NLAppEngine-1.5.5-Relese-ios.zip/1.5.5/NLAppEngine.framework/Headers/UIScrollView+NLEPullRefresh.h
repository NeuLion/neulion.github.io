//
//  UIScrollView+NLEPullRefresh.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum{
	NLPullRefreshPulling = 0,/**< pulling status */
	NLPullRefreshNormal,/**< normal status */
	NLPullRefreshLoading,/**< loading status */
} NLPullRefreshState;

typedef void(^UIScrollViewTriggerRefreshBlock)(UIScrollView *scrollView);

@interface UIScrollView (NLEPullRefresh)

- (void)initPullRefreshHeaderViewWithFetchID:(NSString *)fetchIDString triggerRefreshBlock:(UIScrollViewTriggerRefreshBlock)block;
- (void)pullRefreshHeaderLoadingFinished:(BOOL)succeed;

- (void)initPullRefreshFooterViewWithFetchID:(NSString *)fetchIDString triggerRefreshBlock:(UIScrollViewTriggerRefreshBlock)block;
- (void)pullRefreshFooterLoadingFinished:(BOOL)succeed finalPage:(BOOL)finalPage;

- (void)nlRefreshScrollViewDidScroll:(UIScrollView *)scrollView;
- (void)nlRefreshScrollViewDidEndDragging:(UIScrollView *)scrollView;

- (void)nlRefreshScrollViewUpdateFrame;
- (void)nlRefreshScrollViewUpdateConfigSetting;

+ (void)configTextColor:(UIColor *)color;
+ (void)configLoadingTintColor:(UIColor *)color;

@end
