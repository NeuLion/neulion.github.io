//
//  ComViewControllerShared.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NLEViewControllerShared : UIViewController

- (void)initUI;
- (void)refreshUI;
- (void)cleanViewContent;

@end
