//
//  NLUrlItem.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface NLEUrlItem:NSObject
@property (nonatomic, copy) NSString * nlId;
@property (nonatomic, copy) NSString * url;
@property (nonatomic, assign) BOOL  enable;
//@property (nonatomic, strong) NSDictionary * params;
//@property (nonatomic, strong) NSMutableDictionary * urlParams;

-(NLEUrlItem *)merge:(NLEUrlItem *)urlItem;

-(NSString *)originalURL;

-(id)paramsValueBykey:(NSString *)key;


-(void)replacingUrlItem:(NSDictionary *)dic;
-(void)replacingUrlItem:(NSDictionary *)dic byParamKey:(NSString *)key;

-(NLEUrlItem *)urlItemByNLLocalized;
-(void)setParams:(NSDictionary *)params;
@end
