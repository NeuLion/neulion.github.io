//
//  NLEGeoManager.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import "NLEBaseManager.h"

@interface NLEGeoManager : NLEBaseManager
@property(nonatomic, strong) CLLocation	*currentLocation;

+ (NLEGeoManager *)sharedManager;

@end
