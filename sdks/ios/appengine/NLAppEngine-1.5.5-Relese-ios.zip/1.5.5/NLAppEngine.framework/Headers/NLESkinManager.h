//
//  NLESkinManager.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "NLEBaseManager.h"

#define NLSkinColor(key) \
[[NLESkinManager sharedManager] getSkinColor:(key)]

#define NLSkinFont(key) \
[[NLESkinManager sharedManager] getSkinFont:(key)]

@interface NLESkinManager : NLEBaseManager

+ (NLESkinManager *)sharedManager;

- (UIColor *)getSkinColor:(NSString *)key;
- (UIFont *)getSkinFont:(NSString *)key;

@end
