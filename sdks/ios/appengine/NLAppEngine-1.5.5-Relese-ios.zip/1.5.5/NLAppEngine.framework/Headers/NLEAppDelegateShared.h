//
//  AppDelegateShared.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NLETaskQueue.h"
#import "NLERequestPageStateHelper.h"

@interface NLEAppDelegateShared : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;
@property (nonatomic, strong) NLETaskQueue * launchTaskQueue;

- (void)scheduleLaunchTaskQueue;
- (void)initMainViewWithApplication:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions;

- (void)showPlaceholdSplashView;
- (void)showPlaceholdSplashViewWithViewController:(Class)class nibName:(NSString *)nibName;
#if TARGET_OS_IOS
- (void)showPlaceholdSplashViewWithInterfaceOrientations:(NSUInteger)interfaceOrientations;
- (void)showPlaceholdSplashViewWithStatusBarStyle:(UIStatusBarStyle)style;
- (void)showPlaceholdSplashViewWithStatusBarStyle:(UIStatusBarStyle)style interfaceOrientations:(NSUInteger)interfaceOrientations;
#endif
- (void)removePlaceholdSplashView;

- (void)addReachabilityForInternetNotification;
- (void)removeReachabilityForInternetNotification;
- (void)internetReachableStatusUpdate:(BOOL)isReachable;

- (void)showFullScreenLoadingView:(BOOL)showIndicator;
- (void)showFullScreenLoadingView:(BOOL)showIndicator userInteractionEnabled:(BOOL)enabled;
- (void)showFullScreenLoadingView:(BOOL)showIndicator userInteractionEnabled:(BOOL)enabled loadingStyle:(NLEPageLoadingStyle)style;
- (void)showFullScreenLoadingView:(BOOL)showIndicator showHoldView:(BOOL)showHoldView userInteractionEnabled:(BOOL)enabled loadingStyle:(NLEPageLoadingStyle)style;
- (void)hideFullScreenLoadingView;
+ (void)configFullSreenLoadingIndicatorColor:(UIColor *)color;
+ (void)configFullSreenLoadingIndicatorHoldViewRadius:(CGFloat)radius;
+ (void)configFullSreenLoadingIndicatorHoldViewColor:(UIColor *)color;
+ (void)configFullSreenLoadingIndicatorSize:(CGFloat)size;
+ (void)configFullSreenLoadingSystemIndicatorViewStyle:(UIActivityIndicatorViewStyle)style;

@end

