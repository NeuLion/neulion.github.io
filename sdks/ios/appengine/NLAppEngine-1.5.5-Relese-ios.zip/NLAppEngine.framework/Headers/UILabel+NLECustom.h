//
//  UILabel+NLECustom.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (NLELocalizable)

@property (nonatomic, copy) NSString * NLLocalizedTextKey;

@end


@interface UILabel (NLESkin)

@property (nonatomic, copy) UIFont * NLSkinTextFontKey;

@property (nonatomic ,copy) UIColor * NLSkinTextColorKey;
@property (nonatomic ,copy) UIColor * NLSkinShadowColorKey;
@property (nonatomic ,copy) UIColor * NLSkinHighlightedTextColorKey;

@end