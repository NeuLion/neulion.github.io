//
//  NLEDeepLinkManager.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "NLEBaseManager.h"

@interface NLEDeepLinkManager : NLEBaseManager

+ (NLEDeepLinkManager *)sharedManager;

- (void)handleApplication:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;

-(void)handleDeepLinkActionWithDictionary:(NSDictionary *)dictionary needShowMessage:(BOOL)showMessage;

@end
