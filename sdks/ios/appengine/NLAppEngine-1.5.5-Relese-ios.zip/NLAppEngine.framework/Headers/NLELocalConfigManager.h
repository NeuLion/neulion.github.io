//
//  NLELocalConfigManager.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NLEBaseManager.h"

@interface NLELocalConfigManager : NLEBaseManager

@property (nonatomic, strong, readonly) NSDictionary * localConfigDict;

+ (NLELocalConfigManager *)sharedManager;
- (void)readLocalConfigFile:(NSString *)fileName;

- (NSDictionary *)universalDict;
- (NSDictionary *)phoneDict;
- (NSDictionary *)padDict;

- (id)getPropertyWithkey:(NSString *)key;

- (BOOL)isDebugMode;
- (BOOL)isAllAccessMode;
- (BOOL)isUseLocalConfig;
- (BOOL)isDeepLinkWaitUntilLaunchTaskFinished;
- (NSString *)configURLString;

@end
