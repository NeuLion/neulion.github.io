//
//  NLEUserDefaultManager.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NLEBaseManager.h"
#import "NLEConfigItem.h"
#import <CoreLocation/CoreLocation.h>

@interface NLEUserDefaultManager : NLEBaseManager

+ (NLEUserDefaultManager *)sharedManager;

//local configuration
+ (NLEConfigItem *)getLocalConfiguration;
+ (void)saveLocalConfiguration:(NLEConfigItem *)item;

//hide score
+ (BOOL)isHideScore;
+ (void)setHideScore:(BOOL)hide;

//offline mode
+ (BOOL)getUserForceofflineMode;
+ (void)setUserForceofflineMode:(BOOL)forceofflineMode;

//location
+ (CLLocation *)getLocationInformation;
+ (void)setLocationInfomation:(CLLocation *)location;

//device token
+ (NSString *)getDeviceToken;
+ (void)setDeviceToken:(NSString *)deviceToken;

//localizable file
+ (NSData *)getLocalizable:(NSString *)language;
+ (void)saveLocalizable:(NSString *)language data:(NSData *)item;
+ (NSArray *)getLocalizableAllKey;

@end

extern NSString * const NLEAppScoreSwitchNotification;
