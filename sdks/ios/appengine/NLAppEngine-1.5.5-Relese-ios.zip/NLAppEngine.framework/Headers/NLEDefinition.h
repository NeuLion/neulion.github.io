//
//  NLEDefinition.h
//  NLAppEngine
//
//  Copyright 2014 Neulion Inc. All rights reserved.
//

//Version
#define BUILD_VERSION_ID [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleVersion"]
#define SHORT_VERSION_ID [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]

//Name
#define NLEAppName [[NLELocalConfigManager sharedManager] getPropertyWithkey:@"AppFullName"]?[[NLELocalConfigManager sharedManager] getPropertyWithkey:@"AppFullName"]:[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleDisplayName"]

//Log
#define NLEDebugLog( s, ... ) if([NLEConfigManager sharedManager].configItem.isLogging) NSLog( @"<%p %@:(%d)> %@", self, [[NSString stringWithUTF8String:__FILE__] lastPathComponent], __LINE__, [NSString stringWithFormat:(s), ##__VA_ARGS__] )

//Screen
#define NLEScreenLongSide ([[UIScreen mainScreen] bounds].size.width > [[UIScreen mainScreen] bounds].size.height ? [[UIScreen mainScreen] bounds].size.width : [[UIScreen mainScreen] bounds].size.height)
#define NLEScreenShortSide ([[UIScreen mainScreen] bounds].size.width > [[UIScreen mainScreen] bounds].size.height ? [[UIScreen mainScreen] bounds].size.height : [[UIScreen mainScreen] bounds].size.width)

#define isRetinaScreen              ([[UIScreen mainScreen] scale] == 2)
#define isRetinaHDScreen            ([[UIScreen mainScreen] scale] == 3)
#define isPadUserInterface          (UIUserInterfaceIdiomPad == UI_USER_INTERFACE_IDIOM())
#define isPhoneUserInterface        (UIUserInterfaceIdiomPhone == UI_USER_INTERFACE_IDIOM())
#define isPhone35Inch               (fabs((double)NLEScreenLongSide - (double)480) < DBL_EPSILON)
#define isPhone40Inch               (fabs((double)NLEScreenLongSide - (double)568) < DBL_EPSILON)
#define isPhone47Inch               (fabs((double)NLEScreenLongSide - (double)667) < DBL_EPSILON)
#define isPhone55Inch               (fabs((double)NLEScreenLongSide - (double)736) < DBL_EPSILON)

//Compile Environment
#if __IPHONE_OS_VERSION_MAX_ALLOWED > __IPHONE_5_1
#define IFIOS6OrGreater(...)                                                  \
if (kCFCoreFoundationVersionNumber > kCFCoreFoundationVersionNumber_iOS_5_1) { \
__VA_ARGS__                                                                \
}
#else
#define IFIOS6OrGreater(...)
#endif

#if __IPHONE_OS_VERSION_MAX_ALLOWED > __IPHONE_6_1
#define IFIOS7OrGreater(...)                                                  \
if (kCFCoreFoundationVersionNumber > kCFCoreFoundationVersionNumber_iOS_6_1) { \
__VA_ARGS__                                                                \
}
#else
#define IFIOS7OrGreater(...)
#endif

#if __IPHONE_OS_VERSION_MAX_ALLOWED > __IPHONE_7_1
#define IFIOS8OrGreater(...)                                                  \
if (kCFCoreFoundationVersionNumber > kCFCoreFoundationVersionNumber_iOS_7_1) { \
__VA_ARGS__                                                                \
}
#else
#define IFIOS8OrGreater(...)
#endif

//Convenient
#define NEULION_URL @"http://www.neulion.com"
#define AppSharedDelegate   ((AppDelegateShared *)[UIApplication sharedApplication].delegate)
#define AppPhoneDelegate   ((AppDelegatePhone *)[UIApplication sharedApplication].delegate)
#define AppPadDelegate   ((AppDelegatePad *)[UIApplication sharedApplication].delegate)

//UserDefault
#define ServerURLKey @"serverURL"
