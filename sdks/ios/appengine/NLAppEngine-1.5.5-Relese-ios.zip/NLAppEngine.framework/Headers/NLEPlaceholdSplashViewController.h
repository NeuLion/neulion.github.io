//
//  ComPlaceholdSplashViewController.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NLEPlaceholdSplashViewController : UIViewController

@property (nonatomic, strong) IBOutlet UIImageView * bgImageView;
@property (nonatomic, copy) NSString * imagePrefix; //default is Default
@property (nonatomic, assign) NSUInteger placeholdInterfaceOrientations;
#if TARGET_OS_IOS
@property (nonatomic, assign) UIStatusBarStyle statusBarStyle;
#endif
@end
