//
//  NLEBaseManager.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NLEBaseManager : NSObject

+ (NLEBaseManager *)sharedManager;
+ (Class)instanceClass;
+ (NSString *)configForCurrentClass;
+ (void)readManagerMappingFile:(NSString *)fileName;

@end
