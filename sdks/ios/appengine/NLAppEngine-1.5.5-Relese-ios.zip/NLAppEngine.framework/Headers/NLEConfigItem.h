//
//  NLConfigItem.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NLEUrlItem.h"
#define NLEConfigItemTestEnableChangedNotification               @"NLEConfigItemTestEnableChangedNotification"

#define defaultTestCell  @"Default"
#define testName  @"name"
#define testItems  @"items"
/*
@interface UrlItem:NSObject
@property (nonatomic, copy) NSString * nlId;
@property (nonatomic, copy) NSString * url;
@property (nonatomic, assign) BOOL  enable;
@property (nonatomic, strong) NSDictionary * params;
@property (nonatomic, strong) NSMutableDictionary * urlParams;

-(UrlItem *)merge:(UrlItem *)urlItem;

-(NSString *)originalURL;
-(void)replacingUrlItem:(NSDictionary *)dic;

-(void)replacingUrlItem:(NSDictionary *)dic byParamKey:(NSString *)key;
-(id)paramsValueBykey:(NSString *)key;
@end
*/
@interface NLEConfigItem : NSObject

@property (nonatomic, assign) BOOL testEnable;
@property (nonatomic, strong) NSArray *testConfigs;
@property (nonatomic, strong) NSString * configUrlFromTest;


@property (nonatomic, strong) NSMutableDictionary *services;
@property (nonatomic, strong) NSMutableDictionary *country;
@property (nonatomic, strong) NSMutableDictionary *language;
@property (nonatomic, strong) NSMutableDictionary *platforms;
@property (nonatomic, strong) NSMutableDictionary *appParams;//对外在实现各种直接方法，例如：getDebugLog
@property (nonatomic, strong) NSArray *deviceRedirect;
@property (nonatomic, strong) NSArray *versionRedirect;

@property (nonatomic, strong) NSString * defaultCountry;
@property (nonatomic, strong) NSString * defaultLanguage;


-(id)initConfigItemWithJsonStr:(NSString *)jsonStr;
-(id)initConfigItemBySystemLanguageWithJsonStr:(NSString *)jsonStr;
-(id)initConfigItemWithJsonStr:(NSString *)jsonStr DefaultContry:(NSString *)defaultCountry DefaultLanguage:(NSString *)defaultLanguage;
//-(void)parseJsonStr:(NSString *)jsonsrt;
-(void)addTestByJsonStr:(NSString *)jsonStr;

-(void)setDefaultCountry:(NSString *)defaultCountry;
-(void)setDefaultLanguage:(NSString *)defaultLanguage;
-(void)setDefaultContry:(NSString *)defaultCountry DefaultLanguage:(NSString *)defaultLanguage;
-(BOOL)isDefaultCountryValid;
-(BOOL)isDefaultLanguageValid;



-(void)updateConfigWithTestting;


- (NSString *)redirectUrlStr;


+(BOOL)writeConfigWithJsonStr:(NSString *)jsonStr;
//+(BOOL)writeConfigWithJsonStr:(NSString *)jsonStr FilePath:(NSString *)filePath;
+(NSString *)readConfig;
//+(NSString *)readConfig:(NSString *)filePath;
-(void)readConfigFileAnConfigProperties;


-(NLEUrlItem *)urlItemByNlid:(NSString *)nlid;
-(id)urlItemByNlid:(NSString *)nlid  paramPath:(NSString *)paramPath;


-(NSMutableDictionary *)getUsedConfig;
- (void)saveUsedConfig;


-(void)saveConfigurlFromTest:(NSString *)configurl;
-(NSString *)getConfigurlFromTest;



+(NLEUrlItem *)globalParams;

#pragma mark - 
@property (nonatomic, assign) BOOL isLocalConfig;
@property (nonatomic, assign) BOOL isV2Config;

#pragma mark - appParams
@property (nonatomic, assign) BOOL  isLogging;
@property (nonatomic, assign) BOOL  useAirPlay;
#pragma mark - services
@property (nonatomic, copy) NSString * locServer;
#pragma mark - interval
@property (nonatomic, assign) NSTimeInterval pollInterval;
#pragma mark - qos
@property (nonatomic, assign) BOOL qosEnable;
@property (nonatomic, copy) NSString * qosServer;
@property (nonatomic, copy) NSString * qosSiteID;
@property (nonatomic, assign) NSUInteger qosPeriodTime;
@property (nonatomic, copy) NSString * qosProductID;




@end