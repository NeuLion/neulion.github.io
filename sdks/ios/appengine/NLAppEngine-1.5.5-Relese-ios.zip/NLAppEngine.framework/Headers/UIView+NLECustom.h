//
//  UIView+NLECustom.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (NLESkin)

@property (nonatomic, copy) UIColor * NLSkinColorKey;

@end
