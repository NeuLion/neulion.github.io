//
//  UITextField+NLECustom.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (NLELocalizable)

@property (nonatomic, copy) NSString * NLLocalizedTextKey;
@property (nonatomic, copy) NSString * NLLocalizedPlaceholderKey;

@end


@interface UITextField (NLESkin)

@property (nonatomic, copy) UIFont * NLSkinTextFontKey;

@property (nonatomic ,copy) UIColor * NLSkinTextColorKey;

@end
