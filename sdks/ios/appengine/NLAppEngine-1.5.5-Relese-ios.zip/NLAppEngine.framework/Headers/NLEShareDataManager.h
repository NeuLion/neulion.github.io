//
//  NLEShareDataManager.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NLEBaseManager.h"

@interface NLEShareDataManager : NLEBaseManager
{
    BOOL _isShowScore;
}

@property (nonatomic, assign) BOOL isShowScore;

+ (NLEShareDataManager *)sharedManager;

/*
 default is EST
 read from config -> nl.app.settings -> timezone
 read from NLLocalConfig.plist -> serverTimezone
 */
+ (NSTimeZone *)serverTimezone;

/*
 default is EST
 read from config -> nl.app.settings -> timezone_format
 local read from NLLocalConfig.plist -> localTimezone
 */
+ (NSTimeZone *)localTimezone;

/*
 read from NLLocalConfig.plist -> localTimezoneAbbrDisplayName
 */
+ (NSString *)localTimezoneAbbrDisplayName;

@end

