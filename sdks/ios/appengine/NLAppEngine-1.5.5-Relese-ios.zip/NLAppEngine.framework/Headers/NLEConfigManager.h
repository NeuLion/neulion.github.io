//
//  NLEConfigManager.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NLEBaseManager.h"
#import "NLEConfigItem.h"

@interface NLEConfigManager : NLEBaseManager
{
    NLEConfigItem * _configItem;
}

@property (nonatomic, strong) NLEConfigItem * configItem;

+ (NLEConfigManager *)sharedManager;

@end
