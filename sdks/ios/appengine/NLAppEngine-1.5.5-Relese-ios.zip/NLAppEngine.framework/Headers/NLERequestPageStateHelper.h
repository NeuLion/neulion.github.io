//
//  NLERequestPageStateHelper.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef enum {
    NLERequestPageState_NULL = 0,    //NULL state
    NLERequestPageState_Loading,     //is show loading view
    NLERequestPageState_NoData,      //show no data state
    NLERequestPageState_RequestError,    //fetch error
}NLERequestPageState;

typedef NS_ENUM(NSInteger, NLEPageLoadingStyle) {
    NLEPageLoadingStyleUnknow = -1,
    NLEPageLoadingStyleSystem = 0,
    NLEPageLoadingStylePlane,
    NLEPageLoadingStyleCircleFlip,
    NLEPageLoadingStyleBounce,
    NLEPageLoadingStyleWave,
    NLEPageLoadingStyleWanderingCubes,
    NLEPageLoadingStylePulse,
    NLEPageLoadingStyleChasingDots,
    NLEPageLoadingStyleThreeBounce,
    NLEPageLoadingStyleCircle,
    NLEPageLoadingStyle9CubeGrid,
    NLEPageLoadingStyleWordPress,
    NLEPageLoadingStyleFadingCircle,
    NLEPageLoadingStyleFadingCircleAlt,
    NLEPageLoadingStyleArc,
    NLEPageLoadingStyleArcAlt,
    NLEPageLoadingStyleCustom
};

static NSString * requestFontName = nil;
static UIColor * loadingViewTintColor = nil;
static UIFont * requestFont = nil;
static UIColor * requestTextColor = nil;
static UIColor * requestTextShadowColor = nil;
static NLEPageLoadingStyle staticPageLoadingStyle = 0;
static CGFloat loadingSize = 0;
static NSMutableDictionary * staticTitleDic = nil;

typedef void(^NLERequestPageStateHelperRetryBlock)(NLERequestPageState state);
typedef UIView *(^NLECreateCustomLoadingViewBlock)(void);
typedef void(^NLECustomLoadingViewStateChangedBlock)(UIView * loadingView, BOOL goLoading);

@protocol NLERequestPageStateHelperDelegate;
@interface NLERequestPageStateHelper : NSObject

@property (nonatomic, assign) NLERequestPageState state;
@property (nonatomic, weak, readonly) UIView * ownerPage;
@property (nonatomic, strong) UIView * requestStateView;
@property (nonatomic, strong) UILabel * requestStateLabel;
@property (nonatomic, weak) UIView * aboveView;
@property (nonatomic, weak) UIView * belowView;
@property (nonatomic, assign) CGFloat offsetX;
@property (nonatomic, assign) CGFloat offsetY;
@property (nonatomic, assign) CGFloat loadingOffsetX;
@property (nonatomic, assign) CGFloat loadingOffsetY;
@property (nonatomic, assign) NLEPageLoadingStyle pageLoadingStyle;
@property (nonatomic, strong) UIFont * font;
@property (nonatomic, strong) UIColor * textColor;
@property (nonatomic, strong) UIColor * textShadowColor;
@property (nonatomic, strong) UIColor * loadingTintColor;
@property (nonatomic, assign) BOOL needRetryButton;
@property (nonatomic, copy) NLERequestPageStateHelperRetryBlock retryBlock;
@property (nonatomic, weak) id<NLERequestPageStateHelperDelegate> delegate;
@property (nonatomic, copy) NLECreateCustomLoadingViewBlock createCustomLoadingViewBlock;
@property (nonatomic, copy) NLECustomLoadingViewStateChangedBlock customLoadingViewStateChangedBlock;

- (NLERequestPageStateHelper *)initWithView:(UIView *)view;
- (void)setTitle:(NSString *)title forState:(NLERequestPageState)state;
- (void)refreshView;

+ (void)configFontName:(NSString *)fontName;
+ (void)configFont:(UIFont *)font;
+ (void)configTextColor:(UIColor *)textColor;
+ (void)configTextShadowColor:(UIColor *)shadowColor;
+ (void)configLoadingTintColor:(UIColor *)color;
+ (void)configPageLoadingStyle:(NLEPageLoadingStyle)style;
+ (void)configLoadingSize:(CGFloat)size;
+ (void)setTitle:(NSString *)title forState:(NLERequestPageState)state;

@end

@protocol NLERequestPageStateHelperDelegate <NSObject>
@optional
- (void)requestPageStateHelperClickedRetryEvent:(NLERequestPageStateHelper *)helper;
@end
