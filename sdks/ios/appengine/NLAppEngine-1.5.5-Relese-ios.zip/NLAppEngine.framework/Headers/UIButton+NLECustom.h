//
//  UIButton+NLECustom.h
//  NLAppEngine
//
//  Copyright (c) 2014 NeuLion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (NLELocalizable)

@property (nonatomic, copy) NSString * NLLocalizedNormalTextKey;
@property (nonatomic, copy) NSString * NLLocalizedHighlightedTextKey;
@property (nonatomic, copy) NSString * NLLocalizedSelectedTextKey;
@property (nonatomic, copy) NSString * NLLocalizedDisabledTextKey;

@end


@interface UIButton (NLESkin)

@property (nonatomic, copy) UIFont * NLSkinTextFontKey;

@property (nonatomic, copy) UIColor * NLSkinTextNormalColorKey;
@property (nonatomic, copy) UIColor * NLSkinTextHighlightedColorKey;
@property (nonatomic, copy) UIColor * NLSkinTextSelectedColorKey;
@property (nonatomic, copy) UIColor * NLSkinTextDisabledColorKey;

@property (nonatomic, copy) UIColor * NLSkinTextShadowNormalColorKey;
@property (nonatomic, copy) UIColor * NLSkinTextShadowHighlightedColorKey;
@property (nonatomic, copy) UIColor * NLSkinTextShadowSelectedColorKey;
@property (nonatomic, copy) UIColor * NLSkinTextShadowDisabledColorKey;

@property (nonatomic, copy) UIColor * NLSkinBgNormalColorKey;
@property (nonatomic, copy) UIColor * NLSkinBgHighlightedColorKey;
@property (nonatomic, copy) UIColor * NLSkinBgSelectedColorKey;
@property (nonatomic, copy) UIColor * NLSkinBgDisabledColorKey;

@end
