//
//  NLETestViewControllerShared.h
//  Demo
//
//  Created by yangjun zhu on 15/2/2.
//  Copyright (c) 2015年 NeuLion. All rights reserved.
//

#import <NLAppEngine/NLAppEngine.h>
typedef void(^NLETestViewFetchAppConfigBlock)(void);
#define NLETestChangedNotification               @"NLETestChangedNotification"

@interface NLETestViewControllerShared : NLEViewControllerShared


- (id)initWithConfigItem:(NLEConfigItem *)configItem fetchBlock:(NLETestViewFetchAppConfigBlock)fetchBlock;
-(void)showTestPagePresentedBy:(UIViewController *)viewController;
@end
