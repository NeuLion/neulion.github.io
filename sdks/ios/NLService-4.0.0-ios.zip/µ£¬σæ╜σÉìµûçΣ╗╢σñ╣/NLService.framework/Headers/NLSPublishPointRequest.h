//
//  NLVideoPublishPointRequest.h
//  NeulionService
//
//  Copyright (c) 2014 Neulion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSRequest.h"
#import "NLSDefinition.h"
NS_ASSUME_NONNULL_BEGIN

/** Publishpint type, for video, channel and game. */
typedef enum : NSUInteger{
    NLSPublishPointTypeVideo=0, /**< Video type */
    NLSPublishPointTypeChannel, /**< Channel type */
    NLSPublishPointTypeGame     /**< Game type */
} NLSPublishPointType;

/** For publishpint of game type, describes the stream type with code. */
typedef enum : NSInteger{
    NLSPublishpointGameStreamTypeBroadcastLive,             /**< Game stream type of Broadcast Live*/
    NLSPublishpointGameStreamTypeBroadcastDVR,              /**< Game stream type of Broadcast DVR*/
    NLSPublishpointGameStreamTypeBroadcastArchive,          /**< Game stream type of Broadcast Archive*/
    NLSPublishpointGameStreamTypeHomeLive,                  /**< Game stream type of Home Live */
    NLSPublishpointGameStreamTypeHomeDVR,                   /**< Game stream type of Home DVR*/
    NLSPublishpointGameStreamTypeHomeArchive,               /**< Game stream type of Home Archive*/
    NLSPublishpointGameStreamTypeAwayLive,                  /**< Game stream type of Away Live*/
    NLSPublishpointGameStreamTypeAwayDVR,                   /**< Game stream type of Away DVR*/
    NLSPublishpointGameStreamTypeAwayArchive,               /**< Game stream type of Away Archive*/
    NLSPublishpointGameStreamTypeCondensed,                 /**< Game stream type of Condensed */
    NLSPublishpointGameStreamTypeCondensedHome,             /**< Game stream type of Condensed Home*/
    NLSPublishpointGameStreamTypeCondensedAway,             /**< Game stream type of Condensed Away*/
    NLSPublishpointGameStreamTypeFullContinuousHighlight,   /**< Game stream type of Full Game Highlight*/
    NLSPublishpointGameStreamTypeHalftimeHighlight,         /**< Game stream type of Half Game Highlight */
    NLSPublishpointGameStreamTypeAudioLive,                 /**< Game stream type of Audio Live */
    NLSPublishpointGameStreamTypeAudioDVR,                  /**< Game stream type of Audio DVR */
    NLSPublishpointGameStreamTypeAudioArchive,              /**< Game stream type of Audio Archive */
    NLSPublishpointGameStreamTypeAudioHomeLive,             /**< Game stream type of Audio Home Live */
    NLSPublishpointGameStreamTypeAudioHomeDVR,              /**< Game stream type of Audio Home DVR */
    NLSPublishpointGameStreamTypeAudioHomeArchive,          /**< Game stream type of Audio Home Archive */
    NLSPublishpointGameStreamTypeAudioAwayLive,             /**< Game stream type of Audio Away Live */
    NLSPublishpointGameStreamTypeAudioAwayDVR,              /**< Game stream type of Audio Away DVR */
    NLSPublishpointGameStreamTypeAudioAwayArchive,          /**< Game stream type of Audio Away Archive */
    NLSPublishpointGameStreamTypeHighlight                  /**< Game stream type of PBP Highlight */
} NLSPublishpointGameStreamType;


/**
 *	@brief	This service returns the content publishing point for content playback by the application. A publish point is usually a URL address that the video stream will be attached to. You must use this service to get the playback URL of a video content.
 *  @details If configured, the returned publishing point contains hash tokens for secure streaming.  This service does enforce entitlement for content that require authorization, however, for security reasons, the return does not differentiate between authorization failure and any other failure.  Therefore, for content requiring entitlement, authentication must already be established in the current session.  Additionally, it is up to the application to call other service methods prior to calling this service to determine if the current user has access to the content.  Some entitlement checks include but not limited to subscription access, per-per-view access, and geo-based restrictions such as blackouts.
 */
@interface NLSPublishPointRequest : NLSRequest


/**
 * Publishing point type. Required parameter.
 * @note Possible values: \n
 * @b video     - Specifies that the publishing point of the content to be retrieved is a video.
 * Video can be live, live DVR, or VOD. \n
 * @b channel   - Specifies that the publishing point of the content to be retrieved is a live
 * linear channel. \n
 * @b game      - Specifies that the publishing point of the content to be retrieved is related
 * to a game.
 */
@property (nullable, copy, nonatomic) NSString     *type;

/**
 * The ID of the video, channel or game. Required parameter, if extid is absent.
 * @note Possible values: \n
 * @b video id \n
 * @b channel id \n
 * @b game id
 */
@property (nullable, copy, nonatomic) NSString     *contentId;

/**
 * The external ID of the video, channel or game. Required parameter, if contentId is absent.
 * @note Possible values: \n
 * @b video id \n
 * @b channel id \n
 * @b game id
 */
@property (nullable, copy, nonatomic) NSString     *extid;

/**
 * For projects where the publishing point is external, the publishing point to be encrypted.
 * If this parameter exists, the system will not attempt to look up publishing point but instead,
 * after valid authorization, will use the supplied publishing point for encryption.
 */
@property (nullable, copy, nonatomic) NSString     *pp;

/**
 * Usually only applies when type=video and/or when the content supports multiple bitrate streams.
 * Possible values are device specific and generally the supported bitrate numbers, such as 800, 
 * 1600, etc. It depends on project settings.
 */
@property (nullable, copy, nonatomic) NSString     *bitrate;

/**
 * Only applies for channel DVR Live, video Live event DVR and game DVR. The value is the long 
 * representation of the start time for DVR live playback in GMT.
 * @note Example: 1403069400000 (timeIntervalSince1970)
 */
@property (nullable, copy, nonatomic) NSString     *st;

/**
 * Only applies for channel DVR Live, video Live event DVR and game DVR. The value is the long 
 * representation of the duration for DVR live playback.
 * @note Example: 5400000 (ms)
 */
@property (nullable, copy, nonatomic) NSString     *dur;

/**
 * Specifies the game type of the game publishing point. Only required if type=game.
 * @note Supported values are:\n
 * @b 1 – broadcast\n
 * @b 2 – home\n
 * @b 4 – away\n
 * @b 8 – condensed (broadcast)\n
 * @b 16 – condensed home\n
 * @b 32 – condensed away\n
 * @b 64 – full continuous highlight\n
 * @b 128 – halftime highlight\n
 * @b 256 – audio\n
 * @b 512 – audio home\n
 * @b 1024 – audio away\n
 */
@property (nullable, copy, nonatomic) NSString     *gt;

/**
 * Specifies the game status of the game publishing point. Only required if type=game and gt value supports non-archived streams.
 * @note Supported values are: \n
 * @b 1 – live \n
 * @b 2 – DVR live \n
 * @b 3 – archived \n
 * Only applies when gt is 1, 2, 4, 256, 512, or 1024.
 */
@property (nullable, copy, nonatomic) NSString     *gs;

/**
 * Optional parameter that only has possible value of “true”.  If specified, indicates retrieval of publishing point for trailer.  Used in conjunction with other parameters to specify what content to get.
 */
@property (nullable, copy, nonatomic) NSString     *trailer;

/**
 * Optional parameter that only has possible value of “true”.  If specified, indicates retrieval
 * of publishing point for audio stream only.  Used in conjunction with other parameters to specify 
 * what content to get.
 */
@property (nullable, copy, nonatomic) NSString     *audio;

/**
 * Specifies the camera angle.  Only supported in specific projects that support multi-angle streams.  Usually a zero-based integer number.  Only applicable to type=video or type=game.
 */
@property (nullable, copy, nonatomic) NSString     *cam;

/**
 * Only applies for game highlight, where NLSPublishpointGameStreamType equals to 
 * NLSPublishpointGameStreamTypeHighlight. Specifies the game highlight (event) ID.
 * Only required if type=game and gt=highlight.
 * @see NLSPublishpointGameStreamType
 */
@property (nullable, copy, nonatomic) NSString     *event;

/**
 * Only applies if format=json is specified.  If callback is specified, the JSON output will be padded with this callback function resulting in JSONP output.
 */
@property (nullable, copy, nonatomic) NSString     *callback;


/** Only applicable to mobile devices.  If the network type is known, specifies the network type.*/
@property (nullable, copy, nonatomic) NSString     *nt;

/**
 * Only applicable to content that require authorization and the authorization check is performed 
 * outside of the IPTV platform.  For example, iOS Apple Store purchases that are not linked to the
 * IPTV user account.
 */
@property (nullable, copy, nonatomic) NSString     *token;

/**
 * Only applicable if doing Adobe Pass short media token validation.  This is the Adobe Pass resource
 * ID associated with the short media token.
 */
@property (nullable, copy, nonatomic) NSString     *aprid;

/**
 * Only applicable if doing Adobe Pass short media token validation.  This is the Adobe Pass short
 * media token to be validated.
 */
@property (nullable, copy, nonatomic) NSString     *aptoken;

/**
 * Only applicable if doing Adobe Pass short media token validation and using RSS as the resource ID passing into Adobe Pass. This is the Adobe Pass resource ID in RSS format associated with the short media token.
 */
@property (nullable, copy, nonatomic) NSString     *apridrss;


@property (nullable, copy, nonatomic) NSString     *sku;


@property (nullable, copy, nonatomic) NSString     *live;


@property (nullable, copy, nonatomic) NSString     *download;


@property (nullable, copy, nonatomic) NSString     *ppid;


@property (nullable, copy, nonatomic) NSString     *drmtoken;


@property (nullable, copy, nonatomic) NSString     *deviceid;

/**
 *  @brief  Initialize an instance with channel ID for getting the publish point of Channel type.
 *
 *  @param  channelId The channel ID.
 *
 *  @return The initialized instance.
 */
- (instancetype)initWithChannelId:(NSString *)channelId;

/**
 *  @brief  Initialize an instance with external channel ID for getting the publish point of Channel type.
 *
 *  @param  channelId The external channel ID.
 *
 *  @return The initialized instance.
 */
- (instancetype)initWithExternalChannelId:(NSString *)channelId;

/**
 *  @brief  Initialize an instance with video ID for getting the publish point of Video type.
 *
 *  @param  videoId The channel ID.
 *
 *  @return The initialized instance.
 */
- (instancetype)initWithVideoId:(NSString *)videoId;

/**
 *  @brief  Initialize an instance with external video ID for getting the publish point of Video type.
 *
 *  @param  videoId The external channel ID.
 *
 *  @return The initialized instance.
 */
- (instancetype)initWithExternalVideoId:(NSString *)videoId;

/**
 *  @brief  Initialize an instance with game ID and game stream type for getting the publish point of Game type.
 *
 *  @param  gameId The exteranl game ID.
 *  @param  gameStreamType The game stream type.
 *
 *  @return The initialized instance.
 *
 *  @see NLSPublishpointGameStreamType for more information
 */
- (instancetype)initWithGameId:(NSString *)gameId gameStreamType:(NLSPublishpointGameStreamType)gameStreamType;

/**
 *  @brief  Initialize an instance with external game ID and game stream type for getting the publish point of Game type.
 *
 *  @param  gameId The external ID.
 *  @param  gameStreamType The game stream type.
 *
 *  @return The initialized instance.
 *
 *  @see NLSPublishpointGameStreamType for more information
 */
- (instancetype)initWithExternalGameId:(NSString *)gameId gameStreamType:(NLSPublishpointGameStreamType)gameStreamType;

/**
 *  @brief  Set token with content id , encrypt key and publishpoint type.
 *
 *  @param  key It should be "encryptPrefix" + "num1".
 *
 *  @see NLSPublishPointType for more information
 */
- (void)setTokenWithEncryptKey:(NSString*)key ;

/**
 *  @brief  Set token with content id , encrypt key and publishpoint type.
 *
 *  @param  key It should be "encryptPrefix" + "num1".
 *  @param  contentId The publishpoint content id.
 *  @param  type The publishing point type.
 *
 *  @see NLSPublishPointType for more information
 */
- (void)setTokenWithEncryptKey:(NSString*)key andContentId:(NSString *) contentId andType:(NSString *) type;




- (nullable NSString *)pptJsonString;


- (nullable NSDictionary *)castPPTJsonDictionary;

@end

NS_ASSUME_NONNULL_END

