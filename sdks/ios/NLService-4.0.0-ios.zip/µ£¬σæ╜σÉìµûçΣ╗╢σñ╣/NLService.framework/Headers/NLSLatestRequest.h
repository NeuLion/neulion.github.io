//
//  NLSLatestRequest.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-8-12.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSLatestRequest : NLSRequest

@property (nonatomic, copy) NSString * count;

- (id)initWithCount:(NSString *)count;

@end
NS_ASSUME_NONNULL_END