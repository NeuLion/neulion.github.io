//
//  NLModel.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSObject.h"
#import "NLSParsableDataModelProtocol.h"

@interface NLSModel : NLSObject <NLSParsableDataModelProtocol>

@property (nonatomic, strong) id userInfo;

-(NSArray *)allPropertyNames;
@end
