//
//  NLSLeagueGroup.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-12-19.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"

@interface NLSLeagueGroup : NLSModel

@property (nonatomic, copy) NSString * idString;
@property (nonatomic, copy) NSString * name;

@end
