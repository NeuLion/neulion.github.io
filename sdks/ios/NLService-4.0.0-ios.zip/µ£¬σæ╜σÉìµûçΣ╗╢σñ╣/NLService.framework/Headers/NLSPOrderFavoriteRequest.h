//
//  NLSPOrderFavoriteRequest.h
//  NeuLionService
//
//  Created by Chengming on 16/2/24.
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import "NLSPersonalizeRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSPOrderFavoriteRequest : NLSPersonalizeRequest

//Combined type and content ID with “-” list with comma separator. Such as program-1122,game-33
@property (nullable, nonatomic, copy) NSString * typeIds;

@end
NS_ASSUME_NONNULL_END