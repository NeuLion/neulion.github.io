//
//  NLSessionCheckResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
#import "NLSSessionStatus.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSSessionCheckResponse : NLSResponse

@property (nullable, nonatomic, strong) NLSSessionStatus * data;

- (BOOL)isSessionValid;

@end
NS_ASSUME_NONNULL_END