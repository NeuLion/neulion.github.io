//
//  NLSPSetWatchHistoryRequest.h
//  NeuLionService
//
//  Created by Chengming on 16/2/24.
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import "NLSPersonalizeRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSPSetWatchHistoryRequest : NLSPersonalizeRequest

@property (nullable, nonatomic, copy) NSString * contentId;
//true/false
@property (nullable, nonatomic, copy) NSString * completed;
@property (nullable, nonatomic, copy) NSString * position;
@property (nullable, nonatomic, copy) NSString * type;

@end
NS_ASSUME_NONNULL_END