//
//  NLDynamicLead.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSModel.h"
#import "NLSProgram.h"
#import "NLSGame.h"

@interface NLSDynamicLead : NLSModel

@property (nonatomic, copy) NSString * dynamicLeadId;
@property (nonatomic, assign) NSUInteger type;
@property (nonatomic, copy) NSString * title;
@property (nonatomic, copy) NSString * subTitle;
@property (nonatomic, copy) NSString * dynamicLeadDescription;
@property (nonatomic, copy) NSString * image;
@property (nonatomic, copy) NSString * templateNumber;
@property (nonatomic, copy) NSString * platform;
@property (nonatomic, copy) NSString * link;
@property (nonatomic, strong) NLSProgram * program;
@property (nonatomic, strong) NLSGame * game;

@end
