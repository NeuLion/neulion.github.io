//
//  NLSPRecommendation.h
//  NeuLionService
//
//  Created by Chengming on 16/2/24.
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import "NLSPUserRecord.h"

@interface NLSPRecommendation : NLSModel

@property (nonatomic, copy) NSString * contentId;
@property (nonatomic, copy) NSString * score;
@property (nonatomic, copy) NSString * mahoutUser;
@property (nonatomic, copy) NSString * viewhistory;

@end
