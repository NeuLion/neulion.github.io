//
//  NLSLinearChannel.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-10.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"
#import "NLSBlackoutInfo.h"

@interface NLSLinearChannel : NLSModel

@property (nonatomic, copy) NSString * channelId;
@property (nonatomic, copy) NSString * seoName;
@property (nonatomic, copy) NSString * name;
@property (nonatomic, copy) NSString * channelDescription;
@property (nonatomic, copy) NSString * epg;
@property (nonatomic, copy) NSString * extId;
@property (nonatomic, copy) NLSBlackoutInfo * blackout;
@property (nonatomic, copy) NSString * noAccess;


@end
