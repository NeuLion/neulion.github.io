//
//  NLWhatsNewRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSWhatsNewRequest : NLSRequest{
    NSString *_seoName;
}

@property (nullable, nonatomic, copy) NSString * count;

@property (nullable, nonatomic, copy) NSString * ps;//page size
@property (nullable, nonatomic, copy) NSString * pn;//page number

- (instancetype)initWithSeoName:(NSString *)seoName;

@end
NS_ASSUME_NONNULL_END