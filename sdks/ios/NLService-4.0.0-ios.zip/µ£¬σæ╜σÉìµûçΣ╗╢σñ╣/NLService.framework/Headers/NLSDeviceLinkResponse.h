//
//  NLDeviceLinkResponse.h
//  NeulionService
//
//  Copyright (c) 2014 Neulion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
#import "NLSAuthenticationInfo.h"
NS_ASSUME_NONNULL_BEGIN

@interface NLSDeviceLinkResponse : NLSResponse

@property (copy, nullable, nonatomic) NSString     *code;

@property (nullable, nonatomic, strong) NLSAuthenticationInfo * data;

-(BOOL)isLoginSuccess;

@end
NS_ASSUME_NONNULL_END