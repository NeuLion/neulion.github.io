//
//  NLPurchaseResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN
@class NLSOrderInfo;

@interface NLSPurchaseResponse : NLSResponse

@property (copy, nullable, nonatomic) NSString *code;
@property (nullable, nonatomic, strong) NLSOrderInfo * data;

@end
NS_ASSUME_NONNULL_END