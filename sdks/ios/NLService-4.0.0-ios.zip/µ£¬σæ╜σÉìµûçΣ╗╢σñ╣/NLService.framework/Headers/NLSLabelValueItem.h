//
//  NLSLabelValueItem.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSModel.h"

@interface NLSLabelValueItem : NLSModel

@property (copy, nonatomic) NSString *label;
@property (copy, nonatomic) NSString *value;

@end
