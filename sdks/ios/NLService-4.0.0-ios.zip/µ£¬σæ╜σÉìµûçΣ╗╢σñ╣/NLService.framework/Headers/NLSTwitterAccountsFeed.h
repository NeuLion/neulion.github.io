//
//  NLSTwitterAccountsFeed.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-9.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//
#import "NLSModel.h"

@interface NLSTwitterAccountsFeed : NLSModel

@property (nonatomic, copy) NSString * name;
@property (nonatomic, copy) NSString * url;
@property (nonatomic, copy) NSString * text;

@end
