//
//  NLGameScheduleResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
#import "NLSPaging.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSGameScheduleResponse : NLSResponse

/** 
 * The previous date string that is usually used as the parameter to request the schedule 
 * when clicking the left arrow button. If it is currently requesting the schedule by week,
 * the previousDate could be the date 7 days ago. If it is currently requesting the schedule
 * by date, the previousDate is the date of yesterday.
 */
@property (nullable, nonatomic, copy) NSString * previousDate;

/**
 * The next date string that is usually used as the parameter to request the schedule when
 * clicking the right arrow button. If it is currently requesting the schedule by week, the 
 * nextDate could be the date 7 days ahead. If it is currently requesting the schedule by 
 * date, the nextDate is the date of tomorrow.
 */
@property (nullable, nonatomic, copy) NSString * nextDate;

/** The start date of the week. */
@property (nullable, nonatomic, copy) NSString * startDate;

/** The end date of the week. */
@property (nullable, nonatomic, copy) NSString * endDate;

@property (nullable, nonatomic, strong) NSArray * leagueGroups;
@property (nullable, nonatomic, copy) NSString * leagueGroupId;
@property (nullable, nonatomic, copy) NSString * previousMonth;
@property (nullable, nonatomic, copy) NSString * month;
@property (nullable, nonatomic, copy) NSString * nextMonth;

/**
 * The paging information. Only exists in the data feed if the request supports paging.
 * @see NLSPage for more information
 */
@property (nullable, nonatomic, strong) NLSPaging * paging;

/**
 * The games array.
 * @see NLSGame for more information
 */
@property (nullable, nonatomic, strong) NSArray * games;



@end
NS_ASSUME_NONNULL_END