//
//  NLProgramDetailsRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSProgramDetailsRequest : NLSRequest{
    NSString * _seoName;
}

/** The program ID, correspondig to the "id" parameter in the Program Details API request. */
@property (nullable, nonatomic, copy) NSString * programId;

/** 
 * Optional flag to return categories that this program belongs to. The value should
 * be either "true" or "false".
 */
@property (nullable, nonatomic, copy) NSString * categories;

/**
 *  Initilize a instance with program ID.
 *
 *  @param programId The program ID.
 *
 *  @return The initialized instance.
 */
- (instancetype)initWithProgramId:(NSString *)programId;

/**
 *  The class initialization method that is easy to create and initialize a new instance.
 *
 *  @param programId The program ID.
 *
 *  @return The initialized instance.
 */
+ (instancetype)requestWithProgramId:(NSString *)programId;

- (instancetype)initWithSeoName:(NSString *)seoName;

@end
NS_ASSUME_NONNULL_END