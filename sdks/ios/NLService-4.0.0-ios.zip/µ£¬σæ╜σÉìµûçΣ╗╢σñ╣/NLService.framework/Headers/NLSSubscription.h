//
//  NLSSubscription.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-16.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"
@class NLSMvpdSubs;

@interface NLSSubscription : NLSModel

@property (nonatomic, strong) NSArray * subs;
@property (nonatomic, strong) NSArray * futureSubs;
@property (nonatomic, strong) NLSMvpdSubs * mvpdSubs;

@end
