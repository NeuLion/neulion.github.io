//
//  NLSBillingAddress.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-14.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"

@interface NLSBillingAddress : NLSModel

@property (copy, nonatomic) NSString       *address1;
@property (copy, nonatomic) NSString       *address2;
@property (copy, nonatomic) NSString       *city;
@property (copy, nonatomic) NSString       *state;
@property (copy, nonatomic) NSString       *zip;
@property (copy, nonatomic) NSString       *country;

@end
