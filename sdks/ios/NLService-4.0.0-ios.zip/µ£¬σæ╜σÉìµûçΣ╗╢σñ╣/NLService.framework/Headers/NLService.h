//
//  NLService.h
//  NeuLion Service
//
//  Copyright 2013 Neulion Inc. All rights reserved.
//

/*! \mainpage NeuLion Service SDK Integration (iOS)
 *
 * \section intro_sec Introduction
 * NeuLion Service, also referred as NLServices framework, is an iOS library that interacts with NeuLion
 * backend CMS by querying contents, retrieving publish points, getting schedules, authenticating users
 * and many more.
 *
 * \section overview_sec Framework Overview
 * The NLService framework serves a very simple purpose: forming the service request, sending it to NeuLion
 * CMS, and getting the response.  The framework contains three major base classes:
 * \li NLSClient: this is the main class that links service request and response objects.
 * \li NLSRequest: the base class for the service request.
 * \li NLSResponse: the base class for the response back from the service.
 *
 * For a particular service, there will be an extended NLSRequest class (for example, NLSParticlularServiceRequest)
 * and an extended NLSResponse class (for example, NLSParticularServcieResponse).
 * To call the service, user just needs to instantiate the request class, fills in the request parameters,
 * sends it to the backend service via NLSClient instance.   The request can be sent either synchronously
 * or asynchronously.  The result will come back in the response object.
 
 * \section install_sec How To Use
 *
 * <b>Step 1 Add the files </b>
 * \n  Copy the framework file to your project folder, and add them to your Xcode project.
 * \li NLService.framework
 * \li NLNetworking.framework
 *
 * <b> Step 2 Link the framework </b>
 * \li NLService.framework
 * \li libz.dylib
 * \li MobileCoreServices.framework
 * \li SystemConfiguration.framework
 * \li CoreGraphics.framework
 * \li MapKit.framework
 * \li JavaScriptCore.framework
 *
 * <b> Step 3 Modify build settings </b>
 * \n Add this to "Other Linker Flags" in your project build settings: "-lxml2" and "-all_load".
 * \n Be sure the header file is visible to your project by adding paths to "Header Search Paths" in your
 * project build settings
 *
 * <b> Step 4 Call the API </b>
 * \n <b> Initialization </b>
 * \n Before calling any service, user needs to specify where the service is, which is usually done in the
 * AppDelegate.
 * \li Request a unique app ID from NeuLion.
 * NeuLion support will configure the service and host the settings on its server side.  To initialize it, user can
 * simply call the method below:
 * @code
 *  dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
 *  dispatch_async(queue, ^{
 *     // Start synchronous Client Init method with AppId
 *     [NLSClient setupWithAppKey:appKey
 *                     completion:^(BOOL succeeded, NSError *error){
 *                          if(error){
 *                              NSLog(@"NLSClient setup failed ---- %@", error.localizedDescription);
 *                          }else{
 *                              NSLog(@"NLSClient is successfully set up.");
 *                          }
 *                      }];
 *  });
 * @endcode
 *
 * <b> Request and Response </b>
 * \n Calling the service takes three steps:
 * \li Import header files and instantiate NLSClient class
 * @code
 *  NLSClient *client = [NLSClient sharedInstance];
 * @endcode
 * \li instantiate NLSProgramDetailsRequest class
 * @code
 *  NLProgramDetailsRequest *reqeust = [[NLProgramDetailsRequest alloc] initWithProgramId:@”1420”];
 * @endcode
 * \li send the request out and get the response object back.  This call can be either synchronous or asynchronous.
 * \n Synchronous call:
 * @code
 *  NLProgramDetailsResponse * response = [client getProgramDetailsWithSyncRequest:request];
 * @endcode
 * \n Asynchronous call:
 * @code
 *  [client getProgramDetailsWithAsyncRequest:request
 *                                 completion:^(NLProgramDetailsResponse *response){
 *                                                  if (response.error) {
 *                                                      // Handle error
 *                                                      …
 *                                                  }else{
 *                                                      // Handle valid response.
 *                                                      …
 *                                                  }
 *                                              }];
 * @endcode
 * \n Use the values of the properties in the response object wherever you need.  Each response class has properties
 * corresponding to the returned data structure from the service.
 *
 * \section token_sec Creating the signed token for library initialization
 * In order to secure service calls, you must pass in a signed token during the library initialization.
 * \li Each client must generate a private/public key-pair. The public key is embedded inside a public
 * certificate, and sent to NeuLion. The public certificate states that the key held within can be used for
 * "code-signing" purposes.  (please see below for information about generating private/public key pairs.)
 * \li Private key management is in the hands of the client, as per the industry's long-standing practice.
 * The client generates a private/public key pair, and the public key is made available to NeuLion as a public
 * certificate. NeuLion will never ask for the private key, and there is no need for it to be made available
 * to anyone except the client. Keeping the private key safe is the sole responsibility of each client.
 * \li  Some options to store the key include storing the key locally in the app, or store the externally – for
 * example using a web service to obtain the digitally signed version of the parameter.
 *
 * \n Steps to generate public/private key:
 * \n Generating an Adobe Pass Certificate from Mac Terminal:
 * 1. Generate Private Key      (You will be prompted for a password)
 * @code
 * openssl genrsa -des3 -out private.key 1024
 * @endcode
 * 2. Create Public Key Cert from Private Key    (You will be prompted for company info)
 * @code
 * openssl req -new -x509 -days 3650 -key private.key -out public.crt
 * @endcode
 * 3. Create Public / Private PKCS
 * @code
 * openssl pkcs12 -export -inkey private.key -in public.crt -out private_public.p12 -name "MSG"
 * @endcode
 *
 */

#define NLService_Version @"4.0.0"

#import <NLService/NLSDefinition.h>

#import <NLService/NLSClient.h>
#import <NLService/NLSObject.h>
#import <NLService/NLSRequest.h>
#import <NLService/NLSResponse.h>
#import <NLService/NLSPersonalizationService.h>

// Home Services
#import <NLService/NLSHomeServiceRequest.h>
#import <NLService/NLSHomeServiceResponse.h>

// Media Content Services
#import <NLService/NLSPublishPointRequest.h>
#import <NLService/NLSPublishPointResponse.h>
#import <NLService/NLSProgramDetailsRequest.h>
#import <NLService/NLSProgramDetailsResponse.h>
#import <NLService/NLSCategoryProgramsRequest.h>
#import <NLService/NLSCategoryProgramsResponse.h>
#import <NLService/NLSProgramsRequest.h>
#import <NLService/NLSProgramsResponse.h>

#import <NLService/NLSWhatsNewRequest.h>
#import <NLService/NLSWhatsNewResponse.h>
#import <NLService/NLSWhatsHotRequest.h>
#import <NLService/NLSWhatsHotResponse.h>
#import <NLService/NLSSearchRequest.h>
#import <NLService/NLSSearchResponse.h>
#import <NLService/NLSRelatedProgramsRequest.h>
#import <NLService/NLSRelatedProgramsResponse.h>
#import <NLService/NLSLiveEventsRequest.h>
#import <NLService/NLSLiveEventsResponse.h>
#import <NLService/NLSArchiveEventsRequest.h>
#import <NLService/NLSArchiveEventsResponse.h>
#import <NLService/NLSLinearChannelsRequest.h>
#import <NLService/NLSLinearChannelsResponse.h>
#import <NLService/NLSLinearChannelRequest.h>
#import <NLService/NLSLinearChannelResponse.h>
#import <NLService/NLSLatestRequest.h>
#import <NLService/NLSPopularRequest.h>

// Game Content Services
#import <NLService/NLSGameDatesRequest.h>
#import <NLService/NLSGameDatesResponse.h>
#import <NLService/NLSGameScheduleRequest.h>
#import <NLService/NLSGameScheduleResponse.h>
#import <NLService/NLSGameDetailResponse.h>
#import <NLService/NLSGameDetailRequest.h>
#import <NLService/NLSScoreboardRequest.h>
#import <NLService/NLSScoreboardResponse.h>
#import <NLService/NLSCheckGamesRequest.h>
#import <NLService/NLSCheckGamesResponse.h>
#import <NLService/NLSGameTwitterAccountsRequest.h>
#import <NLService/NLSGameTwitterAccountsResponse.h>


// Authendication Services
#import <NLService/NLSAuthenticationRequest.h>
#import <NLService/NLSAuthenticationResponse.h>
#import <NLService/NLSAuthenticateReceiptRequest.h>
#import <NLService/NLSAuthenticateReceiptResponse.h>
#import <NLService/NLSDeviceLinkRequest.h>
#import <NLService/NLSDeviceLinkResponse.h>
#import <NLService/NLSDeviceUnlinkRequest.h>
#import <NLService/NLSDeviceUnlinkResponse.h>
#import <NLService/NLSSessionCheckRequest.h>
#import <NLService/NLSSessionCheckResponse.h>
#import <NLService/NLSEndSessionRequest.h>
#import <NLService/NLSEndSessionResponse.h>
#import <NLService/NLSSendResetPasswordEmailRequest.h>
#import <NLService/NLSSendResetPasswordEmailResponse.h>
#import <NLService/NLSSendActivationEmailRequest.h>
#import <NLService/NLSSendActivationEmailResponse.h>

// Account Services
#import <NLService/NLSMyProfileRequest.h>
#import <NLService/NLSMyProfileResponse.h>
#import <NLService/NLSProfileUpdateRequest.h>
#import <NLService/NLSProfileUpdateResponse.h>
#import <NLService/NLSBillingInformationRequest.h>
#import <NLService/NLSBillingInformationResponse.h>
#import <NLService/NLSBillingUpdateRequest.h>
#import <NLService/NLSBillingUpdateResponse.h>
#import <NLService/NLSSubscriptionsRequest.h>
#import <NLService/NLSSubscriptionsResponse.h>
#import <NLService/NLSPayPerViewOrdersRequest.h>
#import <NLService/NLSPayPerViewOrdersResponse.h>
#import <NLService/NLSLanguageChangeRequest.h>
#import <NLService/NLSLanguageChangeResponse.h>
#import <NLService/NLSUpsellUpdateRequest.h>
#import <NLService/NLSUpsellUpdateResponse.h>
#import <NLService/NLSApplyPPVCreditRequest.h>
#import <NLService/NLSApplyPPVCreditResponse.h>

// Registration & Purchase Services
#import <NLService/NLSRegistrationFormRequest.h>
#import <NLService/NLSRegistrationFormResponse.h>
#import <NLService/NLSRegistrationRequest.h>
#import <NLService/NLSRegistrationResponse.h>
#import <NLService/NLSCheckUsernameAvailabilityRequest.h>
#import <NLService/NLSCheckUsernameAvailabilityResponse.h>
#import <NLService/NLSPurchaseFormRequest.h>
#import <NLService/NLSPurchaseFormResponse.h>
#import <NLService/NLSPurchaseRequest.h>
#import <NLService/NLSPurchaseResponse.h>
#import <NLService/NLSTotalCostRequest.h>
#import <NLService/NLSTotalCostResponse.h>
#import <NLService/NLSGetProductsRequest.h>
#import <NLService/NLSGetProductsResponse.h>

// Personalize
#import <NLService/NLSPGetAccessTokenRequest.h>
#import <NLService/NLSPGetAccessTokenResponse.h>
#import <NLService/NLSPersonalizeRequest.h>
#import <NLService/NLSPersonalizeResponse.h>
#import <NLService/NLSPGetUserRequest.h>
#import <NLService/NLSPGetUserResponse.h>
#import <NLService/NLSPSetUserRequest.h>
#import <NLService/NLSPSetUserResponse.h>
#import <NLService/NLSPListWatchHistoryRequest.h>
#import <NLService/NLSPListWatchHistoryResponse.h>
#import <NLService/NLSPSetWatchHistoryRequest.h>
#import <NLService/NLSPSetWatchHistoryResponse.h>
#import <NLService/NLSPDeleteWatchHistoryRequest.h>
#import <NLService/NLSPDeleteWatchHistoryResponse.h>
#import <NLService/NLSPListRatingRequest.h>
#import <NLService/NLSPListRatingResponse.h>
#import <NLService/NLSPSetRatingRequest.h>
#import <NLService/NLSPSetRatingResponse.h>
#import <NLService/NLSPDeleteRatingRequest.h>
#import <NLService/NLSPDeleteRatingResponse.h>
#import <NLService/NLSPScoreRatingRequest.h>
#import <NLService/NLSPScoreRatingResponse.h>
#import <NLService/NLSPContentScoreRatingRequest.h>
#import <NLService/NLSPContentScoreRatingResponse.h>
#import <NLService/NLSPListFavoriteRequest.h>
#import <NLService/NLSPListFavoriteResponse.h>
#import <NLService/NLSPSetFavoriteRequest.h>
#import <NLService/NLSPSetFavoriteResponse.h>
#import <NLService/NLSPDeleteFavoriteRequest.h>
#import <NLService/NLSPDeleteFavoriteResponse.h>
#import <NLService/NLSPOrderFavoriteRequest.h>
#import <NLService/NLSPOrderFavoriteResponse.h>
#import <NLService/NLSPListPlaylistRequest.h>
#import <NLService/NLSPListPlaylistResponse.h>
#import <NLService/NLSPGetPlaylistRequest.h>
#import <NLService/NLSPGetPlaylistResponse.h>
#import <NLService/NLSPSetPlaylistRequest.h>
#import <NLService/NLSPSetPlaylistResponse.h>
#import <NLService/NLSPDeletePlaylistRequest.h>
#import <NLService/NLSPDeletePlaylistResponse.h>
#import <NLService/NLSPOrderPlaylistRequest.h>
#import <NLService/NLSPOrderPlaylistResponse.h>
#import <NLService/NLSPListRecommendedRequest.h>
#import <NLService/NLSPListRecommendedResponse.h>
#import <NLService/NLSPAnalyzeRecommendedRequest.h>
#import <NLService/NLSPAnalyzeRecommendedResponse.h>
#import <NLService/NLSPHideRecommendedRequest.h>
#import <NLService/NLSPHideRecommendedResponse.h>
#import <NLService/NLSPShowRecommendedRequest.h>
#import <NLService/NLSPShowRecommendedResponse.h>
#import <NLService/NLSPListContentRequest.h>
#import <NLService/NLSPListContentResponse.h>


// Data Types
#import <NLService/NLSModel.h>
#import <NLService/NLSProgram.h>
#import <NLService/NLSProgramPurchase.h>
#import <NLService/NLSBundlePurchase.h>
#import <NLService/NLSBlackoutInfo.h>
#import <NLService/NLSProgramProduct.h>
#import <NLService/NLSPrice.h>
#import <NLService/NLSPayPerView.h>
#import <NLService/NLSCategory.h>
#import <NLService/NLSDynamicLead.h>
#import <NLService/NLSGame.h>
#import <NLService/NLSGameDate.h>
#import <NLService/NLSNavigationItem.h>
#import <NLService/NLSPaging.h>
#import <NLService/NLSSport.h>
#import <NLService/NLSTeam.h>
#import <NLService/NLSDateOfBirth.h>
#import <NLService/NLSCriteria.h>
#import <NLService/NLSOptionItem.h>
#import <NLService/NLSYearRange.h>
#import <NLService/NLSBillingAddress.h>
#import <NLService/NLSCreditCard.h>
#import <NLService/NLSOrderInfo.h>
#import <NLService/NLSTotalCostInfo.h>
#import <NLService/NLSProduct.h>
#import <NLService/NLSAuthenticationInfo.h>
#import <NLService/NLSPayPerViewOrder.h>
#import <NLService/NLSSubscriptionItem.h>
#import <NLService/NLSSubscriptionDetailItem.h>
#import <NLService/NLSSubscription.h>
#import <NLService/NLSMvpdSubs.h>
#import <NLService/NLSLeagueGroup.h>
#import <NLService/NLSChannelEPGItem.h>
#import <NLService/NLSEPGItem.h>
#import <NLService/NLSEPGRequest.h>
#import <NLService/NLSEPGResponse.h>
#import <NLService/NLSProfile.h>
#import <NLService/NLSUser.h>
#import <NLService/NLSContactAddress.h>
#import <NLService/NLSAttributeInfo.h>
#import <NLService/NLSLinearChannel.h>
#import <NLService/NLSBilling.h>
#import <NLService/NLSLabelValueItem.h>
#import <NLService/NLSTwitterAccountsFeed.h>


#import <NLService/NLSPUserRecord.h>
#import <NLService/NLSPRecommendation.h>
#import <NLService/NLSPUserHistory.h>
#import <NLService/NLSPUserPersonalization.h>
#import <NLService/NLSPUserRating.h>
#import <NLService/NLSPPaging.h>
#import <NLService/NLSProgramGroup.h>

#import <NLService/NLSUtil.h>
