//
//  NLLiveEventsResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN

@interface NLSLiveEventsResponse : NLSResponse

@property (nullable, nonatomic, copy) NSString * currentDate;
@property (nullable, nonatomic, strong) NSArray * programs;

@end
NS_ASSUME_NONNULL_END