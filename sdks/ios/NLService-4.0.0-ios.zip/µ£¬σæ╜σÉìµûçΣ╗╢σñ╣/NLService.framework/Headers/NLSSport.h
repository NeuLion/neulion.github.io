//
//  NLSport.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import <Foundation/Foundation.h>
#import "NLSModel.h"

@interface NLSSport : NLSModel

@property (nonatomic, copy) NSString * sportId;
@property (nonatomic, copy) NSString * abbr;
@property (nonatomic, copy) NSString * name;

@end
