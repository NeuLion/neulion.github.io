//
//  NLGameScheduleByMonthResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
#import "NLSPaging.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSGameDatesResponse : NLSResponse

/**
 *  The previous month string in format of yyyy-MM, e.g. "2013-05".
 */
@property (nullable, nonatomic, copy) NSString * previousMonth;

/**
 *  The current month in format of yyyy-MM, e.g. "2013-06".
 */
@property (nullable, nonatomic, copy) NSString * month;

/**
 *  The next month string in format of yyyy-MM, e.g. "2013-07".
 */
@property (nullable, nonatomic, copy) NSString * nextMonth;

/**
 *  The paging information. Only exists in the data feed if the request supports paging.
 */
@property (nullable, nonatomic, strong) NLSPaging * paging;

/**
 *  The GameDate array containing the dates on which games take place and the count of games.
 */
@property (nullable, nonatomic, strong) NSArray * gamedates;

@end
NS_ASSUME_NONNULL_END