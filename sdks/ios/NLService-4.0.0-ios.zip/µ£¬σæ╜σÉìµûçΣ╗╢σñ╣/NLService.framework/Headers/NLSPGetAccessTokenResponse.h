//
//  NLSPGetAccessTokenResponse.h
//  NeuLionService
//
//  Created by Chengming on 16/2/25.
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSPGetAccessTokenResponse : NLSResponse

@property (nullable, nonatomic, copy) NSString * accessToken;

@end
NS_ASSUME_NONNULL_END