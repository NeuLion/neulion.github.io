//
//  NLSDateOfBirth.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-10.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"

@interface NLSDateOfBirth : NLSModel

@property (nonatomic, copy) NSString *minAge;
@property (nonatomic, copy) NSString *maxYear;
@property (nonatomic, copy) NSString *minYear;

@end
