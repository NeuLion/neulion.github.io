//
//  NLSGameDatesRequest.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSGameDatesRequest : NLSRequest

/**
 *The sports ID used as a filter field. Usually the abbreviation of sport, e.g.
 *“BK” stands for basketball.
 */
@property (nullable, nonatomic, copy) NSString * sid;

@property (nullable, nonatomic, copy) NSString * sids;

/** The league ID used as a filter field. Usually the abbreviation of sport league name. */
@property (nullable, nonatomic, copy) NSString * lid;

/** The team ID used as a filter field. Usually the abbreviation of the team name. */
@property (nullable, nonatomic, copy) NSString * tid;

@property (nullable, nonatomic, copy) NSString * tids;

/** The page size for paging. The default value is 10. */
@property (nullable, nonatomic, copy) NSString * ps;

/** The page number. The default value is 1. */
@property (nullable, nonatomic, copy) NSString * pn;

/** The value should match format yyyy-MM or just equals “today”. If the month is set, query the schedule by month starting with specified date or today. 
 *  @note Example: “2013-05-20” or “today”
 */
@property (copy, nullable, nonatomic) NSString *month;

/**
 *  The class initialization method that is easy to create and initialize a new instance for requesting the game date list containing the dates on which games take place and the count of games..
 *
 *  @param month The month.
 *
 *  @return The initialized instance. Used to get a game date list based on the specified month.
 */
-(instancetype)initWithMonth:(NSString *)month;

@end
NS_ASSUME_NONNULL_END
