//
//  NLSContactAddress.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-15.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"

@interface NLSContactAddress : NLSModel

@property (nonatomic, copy) NSString * address1;
@property (nonatomic, copy) NSString * address2;
@property (nonatomic, copy) NSString * city;
@property (nonatomic, copy) NSString * state;
@property (nonatomic, copy) NSString * country;

@end
