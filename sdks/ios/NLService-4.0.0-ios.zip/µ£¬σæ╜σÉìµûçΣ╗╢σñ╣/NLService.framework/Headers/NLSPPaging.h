//
//  NLSPPaging.h
//  NeuLionService
//
//  Created by Chengming on 16/2/24.
//  Copyright © 2016 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"

@interface NLSPPaging : NLSModel

/** The count of the records. */
@property (nonatomic, assign) NSUInteger count;

/** The page number. The default value is 1. The page number starts from 1. */
@property (nonatomic, assign) NSUInteger pageNumber;

/** The count of the pages. */
@property (nonatomic, assign) NSUInteger totalPage;

@end
