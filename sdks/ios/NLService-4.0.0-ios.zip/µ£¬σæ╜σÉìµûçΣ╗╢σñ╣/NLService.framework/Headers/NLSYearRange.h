//
//  NLSYearRange.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-14.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"

@interface NLSYearRange : NLSModel

@property (nonatomic, copy) NSString * min;
@property (nonatomic, copy) NSString * max;

@end
