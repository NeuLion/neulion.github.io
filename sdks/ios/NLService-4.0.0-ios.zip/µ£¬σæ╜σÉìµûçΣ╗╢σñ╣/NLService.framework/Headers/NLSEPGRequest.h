//
//  NLSEPGRequest.h
//  NeuLionService
//
//  Created by NeuLion Developer on 15-2-26.
//  Copyright (c) 2015 NeuLion, Inc. All rights reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSEPGRequest : NLSRequest

- (id)initWithDate:(NSDate *)date andFeedUrlPrefix:(NSString *)url;
- (id)initWithDate:(NSDate *)date andFeedFormat:(NSString *)url;

@end
NS_ASSUME_NONNULL_END
