//
//  NLSSubscriptionDetailItem.h
//  NeuLionService
//
//  Created by Chengming on 16/10/12.
//  Copyright © 2016年 NeuLion, Inc. All rights reserved.
//

#import <NLService/NLService.h>

@interface NLSSubscriptionDetailItem : NLSModel

@property (nonatomic, copy) NSString * detailId;
@property (nonatomic, copy) NSString * type;
@property (nonatomic, copy) NSString * ppvCreditsRemaining;

@end
