//
//  NLSscoreboard.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-9.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN
@class NLSPaging;

@interface NLSScoreboardResponse : NLSResponse
@property (nullable, nonatomic, strong) NSArray * leagueGroups;
@property (nullable, nonatomic, copy) NSString * leagueGroupId;
@property (nullable, nonatomic, copy) NSString * previousMonth;
@property (nullable, nonatomic, copy) NSString * month;
@property (nullable, nonatomic, copy) NSString * nextMonth;
@property (nullable, nonatomic, strong) NLSPaging * paging;
@property (nullable, nonatomic, strong) NSArray *games;

@property (nullable, nonatomic, copy) NSString * previousDate;
@property (nullable, nonatomic, copy) NSString * nextDate;
@property (nullable, nonatomic, copy) NSString * startDate;
@property (nullable, nonatomic, copy) NSString * endDate;

@end
NS_ASSUME_NONNULL_END