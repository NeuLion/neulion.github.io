//
//  NLPayPerViewOrdersResponse.h
//  NeuLionService
//
//  Copyright (c) 2014 NeuLion, Inc. All Rights Reserved.
//

#import "NLSResponse.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSPayPerViewOrdersResponse : NLSResponse

@property (nullable, nonatomic, copy  ) NSString      *code;
@property (nullable, nonatomic, strong) NSArray       *orders;

@end
NS_ASSUME_NONNULL_END