//
//  NLSMvpdSubs.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-16.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"

@interface NLSMvpdSubs : NLSModel

@property (nonatomic, strong) NSArray * channels;

@end
