//
//  NLSProfile.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-15.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"
@class NLSOptionItem;
@class NLSUser;
@class NLSContactAddress;
@class NLSAttributeInfo;

@interface NLSProfile : NLSModel

@property (nonatomic, strong) NSArray           * locales;
@property (nonatomic, copy) NLSUser             * user;
@property (nonatomic, copy) NLSContactAddress   * contactAddress;
@property (nonatomic, strong) NSArray           * attributes;

@end
