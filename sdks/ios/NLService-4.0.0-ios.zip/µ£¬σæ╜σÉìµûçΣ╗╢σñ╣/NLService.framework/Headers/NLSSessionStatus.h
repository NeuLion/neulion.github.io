//
//  NLSSessionStatus.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-10.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSModel.h"

@interface NLSSessionStatus : NLSModel

@property(nonatomic, copy)      NSString * currentDate;
@property(nonatomic, copy)      NSString * isLoggedIn;
@property(nonatomic, copy)      NSString * subExpired;
@property(nonatomic, copy)      NSString * uid;

@end
