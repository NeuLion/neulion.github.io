//
//  NLSScoreboard.h
//  NeuLionService
//
//  Created by NeuLion Developer on 14-7-9.
//  Copyright (c) 2014 NeuLion, Inc. All rights reserved.
//

#import "NLSRequest.h"
NS_ASSUME_NONNULL_BEGIN
@interface NLSScoreboardRequest : NLSRequest

@property (nullable, nonatomic, copy) NSString * sid;
@property (nullable, nonatomic, copy) NSString * lid;
@property (nullable, nonatomic, copy) NSString * tid;
@property (nullable, nonatomic, copy) NSString * ac;
@property (nullable, nonatomic, copy) NSString * lgid;


@end
NS_ASSUME_NONNULL_END